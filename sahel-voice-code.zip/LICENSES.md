# Licences

## Code de Sahel Voice
© 2026 Abou Soufiane Laouali Ousmane. Tous droits réservés.

## Bibliothèques utilisées (v0.1)
| Bibliothèque | Licence |
|---|---|
| AndroidX Core, Activity, Jetpack Compose (UI, Foundation, Material 3) | Apache 2.0 |
| Kotlin standard library | Apache 2.0 |
| llama.cpp / ggml (ggml-org), version b11800 | MIT |
| Vosk Android (com.alphacephei:vosk-android 0.3.75) | Apache 2.0 |
| JNA (net.java.dev.jna 5.18.1) | Apache 2.0 / LGPL 2.1 |
| Modèle vosk-model-small-fr-0.22 (importé par l'utilisateur) | Apache 2.0 |

## Moteurs vocaux (v0.1)
Aucun modèle n'est inclus dans l'APK. L'application utilise les services déjà installés sur le téléphone :
- reconnaissance vocale d'Android (fournie par Google ou le fabricant) ;
- synthèse vocale d'Android (par exemple « Services de reconnaissance vocale de Google »).
Leurs conditions d'utilisation sont celles de leurs éditeurs.

## Modèles prévus (à vérifier avant intégration)
| Composant | Candidat | Licence connue | Remarque |
|---|---|---|---|
| Reconnaissance (phase 4) | Whisper (whisper.cpp) | MIT | Haoussa pris en charge mais de qualité faible : à tester |
| Voix haoussa | Meta MMS-TTS via sherpa-onnx | CC-BY-NC 4.0 | Usage non commercial seulement |
| Conversation (phase 5) | Qwen2.5-0.5B/1.5B Instruct (GGUF, llama.cpp) | Apache 2.0 | Haoussa faible ; vitesse à mesurer sur Redmi 12 |
