# Tests sur le Redmi 12 — version 0.1

Règle : on ne coche **Réussi** que si le résultat a été réellement observé sur le téléphone.
Pour chaque test : noter le résultat obtenu et le temps de réponse approximatif.

| # | Commande | Langue | Résultat attendu | Résultat obtenu | Temps | Réussi ? |
|---|---|---|---|---|---|---|
| 1 | « Ouvre WhatsApp » (voix) | FR | WhatsApp s'ouvre | | | |
| 1b | «افتح واتساب» (voix) | AR | WhatsApp s'ouvre | | | |
| 1c | «Buɗe WhatsApp» (écrit puis voix) | HA | WhatsApp s'ouvre | | | |
| 2 | « Allume la lampe » puis « Éteins la lampe » | FR | La lampe s'allume puis s'éteint | | | |
| 2b | «Kunna fitila» / «Kashe fitila» | HA | Idem | | | |
| 3 | « Crée une alarme à six heures » | FR | Alarme 06:00 visible dans Horloge | | | |
| 3b | «أنشئ منبهاً الساعة السابعة والنصف» | AR | Alarme 07:30 | | | |
| 4 | « Augmente le volume » / « Baisse le volume » | FR | Le volume change, % affiché | | | |
| 5 | « Quelle heure est-il ? » / « Quelle est la date ? » | FR | Heure et date justes | | | |
| 6 | Réponse lue à voix haute | FR | Voix française audible | | | |
| 7 | Réponse lue à voix haute | AR | Voix arabe audible | | | |
| 8 | Réponse en haoussa | HA | Texte haoussa affiché (pas de voix attendue) | | | |
| 9 | « Répète » | FR | La dernière réponse est relue | | | |
| 10 | « Arrête de parler » pendant une réponse | FR | La voix s'arrête | | | |
| 11 | 🗑 puis « Effacer » | — | L'historique disparaît | | | |
| 12 | Redémarrer le téléphone, rouvrir l'app | — | L'app s'ouvre, réglages conservés | | | |
| 13 | Mode avion + 🎤 « Allume la lampe » | FR | Indiquer si la voix est reconnue | | | |
| 13b | Mode avion + 🎤 | AR | Indiquer si la voix est reconnue | | | |
| 13c | Mode avion + 🎤 | HA | Indiquer si la voix est reconnue | | | |
| 14 | Mode avion + commandes écrites | FR/AR/HA | Toutes les commandes marchent | | | |
| 15 | Ouvrir beaucoup d'applications puis Sahel Voice | — | Pas de fermeture brutale | | | |

## Ce qu'il faut me renvoyer
- Le tableau rempli (ou des captures d'écran).
- Les deux petites lignes affichées au-dessus du champ de texte (état de la voix et de la reconnaissance), pour chaque langue.
