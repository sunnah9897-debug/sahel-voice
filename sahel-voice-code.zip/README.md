# SAHEL VOICE

Assistant vocal Android **trilingue** (français, arabe, haoussa), **privé** et **léger**, conçu pour fonctionner sans Internet.
Développé sans ordinateur : le code est sur GitHub et l'APK est compilé automatiquement par GitHub Actions.

Auteur : Abou Soufiane Laouali Ousmane — Maradi, Niger.

---

## 📲 Installer l'application sur le téléphone

1. Ouvrir la page **Releases** du dépôt (lien « Releases » à droite ou en bas de la page d'accueil du dépôt).
2. Dans la dernière version (« Latest »), toucher le fichier **SahelVoice-v0.1.X.apk**.
3. Quand Chrome demande, toucher **Télécharger**, puis **Ouvrir**.
4. Si Android bloque : autoriser **Chrome** à installer des applications inconnues, puis revenir et toucher **Installer**.
5. Au premier appui sur 🎤, accepter l'autorisation du **micro**.

Les nouvelles versions s'installent **par-dessus** l'ancienne (l'historique est conservé).

## 🔁 Mettre à jour / recompiler

Chaque modification envoyée sur la branche `main` lance automatiquement une compilation
(onglet **Actions** du dépôt). Une compilation dure en général quelques minutes.
Pour relancer sans modifier : **Actions** › **Compiler l'APK** › **Run workflow**.

En cas d'échec (croix rouge ❌) : ouvrir la compilation, toucher l'étape en rouge, faire une capture d'écran du message d'erreur.

## ✅ Ce que fait la version 0.1

| Fonction | Exemple (FR / AR / HA) | Fonctionne sans Internet ? |
|---|---|---|
| Lampe | « Allume la lampe » / «شغّل المصباح» / «Kunna fitila» | Oui |
| Volume | « Augmente le volume » / «ارفع الصوت» / «Ƙara sauti» | Oui |
| Batterie | « Batterie » / «كم نسبة البطارية؟» / «Nawa batirin ya rage?» | Oui |
| Heure, date | « Quelle heure est-il ? » / «كم الساعة؟» / «Ƙarfe nawa?» | Oui |
| Alarme | « Crée une alarme à six heures » / «أنشئ منبهاً الساعة السادسة» / «Saita ƙararrawa da ƙarfe shida» | Oui (via l'app Horloge) |
| Ouvrir une app | « Ouvre WhatsApp » / «افتح واتساب» / «Buɗe WhatsApp» | Oui |
| Caméra, Paramètres | « Ouvre la caméra » / «افتح الإعدادات» / «Buɗe saituna» | Oui |
| Préparer un appel | « Appelle 98 97 14 36 » | Oui (vous appuyez vous-même sur Appeler) |
| Répéter, se taire, effacer | « Répète », « Arrête de parler », « Efface la conversation » | Oui |
| Commandes écrites | Champ de texte en bas de l'écran | Oui |
| Voix (synthèse) | Réponses lues à voix haute | FR/AR : oui si la voix hors ligne est installée. HA : pas de voix → texte |
| Reconnaissance vocale | Bouton 🎤 | Dépend du téléphone (voir ci-dessous) |

**Pas encore** : conversation libre avec une IA locale (prévue en phase 5), mot d'activation, SMS, rappels.

## 🔒 Confidentialité (vérifiable)

- Le fichier `app/src/main/AndroidManifest.xml` **ne contient pas** la permission `INTERNET` :
  Android interdit donc à Sahel Voice d'envoyer quoi que ce soit sur le réseau.
- L'historique et les réglages restent dans le téléphone (`SharedPreferences`), effaçables avec 🗑.
- Le micro ne s'active que lorsque vous touchez 🎤, et s'arrête si l'application passe en arrière-plan.
- Les appels ne sont jamais lancés seuls : l'écran du téléphone s'ouvre avec le numéro, vous confirmez.

⚠️ La **reconnaissance vocale** de la v0.1 utilise le service vocal d'Android (souvent Google), qui est
une application séparée. L'écran indique le mode utilisé :
- « Reconnaissance sur le téléphone » : traitement local (Android 13+, si la langue est installée) ;
- « service Android (peut utiliser Internet) » : ce service peut envoyer la voix à Google si la langue
  n'est pas disponible hors ligne. **Test à faire en mode avion.**
Une reconnaissance 100 % intégrée (whisper.cpp / sherpa-onnx) est prévue en phase 4.

## 🧭 Décisions techniques

| Date | Décision | Raison |
|---|---|---|
| 22/10/2026 | Kotlin + Jetpack Compose, minSdk 26, targetSdk 35 | Standard Android actuel, Redmi 12 = Android 13+ |
| 22/10/2026 | Compilation par GitHub Actions, dépôt public | Gratuit pour les dépôts publics, aucun ordinateur requis |
| 22/10/2026 | APK publié dans **Releases** | Téléchargement direct depuis Chrome (pas de .zip) |
| 22/10/2026 | Commandes par mots-clés (pas d'IA) en v0.1 | Rapide, fiable, presque aucune mémoire (4 Go de RAM) |
| 22/10/2026 | Reconnaissance/synthèse d'Android en v0.1 | Permet un APK utilisable tout de suite ; moteur intégré en phase 4 |
| 22/10/2026 | Pas de permission INTERNET | Garantie de confidentialité contrôlée par Android |
| 22/10/2026 | Clé de signature de **test** dans `keystore/` | Même clé à chaque compilation → mises à jour sans désinstaller |

### À propos de la clé de test
`keystore/sahelvoice-test.jks` (mot de passe `sahelvoice`) est une clé **de test**, publique.
Elle suffit pour un usage personnel. **Avant toute diffusion publique** (Play Store, partage large),
il faudra créer une vraie clé privée et la placer dans les *Secrets* GitHub, jamais dans le code.

## 📝 Historique des versions

- **v0.1.1** (22/10/2026) : première version installée et testée sur le Redmi 12.
  Résultats observés : heure ✅, lampe ✅, WhatsApp ✅, alarme 06:30 ✅, voix FR hors ligne ✅,
  reconnaissance FR sur le téléphone ✅. Problèmes : plantage en arabe, voix arabe muette.
- **v0.1.2** : correction du plantage (boucle infinie lors d'une erreur de reconnaissance vocale),
  voix protégée contre les erreurs, lien « Installer / vérifier la voix », enregistreur de plantage
  affiché au démarrage suivant, « arrête » seul ne coupe plus la parole, langue devinée pour
  les phrases non comprises.

## 🗂 Structure

```
app/src/main/java/com/sahelvoice/app/
  MainActivity.kt   – démarrage, autorisation du micro
  Screen.kt         – écran (Compose), droite-à-gauche pour l'arabe
  Theme.kt          – couleurs claires / sombres
  Assistant.kt      – reçoit une phrase, choisit l'action, répond
  CommandEngine.kt  – compréhension des commandes FR/AR/HA, lecture des heures, noms d'applications
  PhoneActions.kt   – lampe, volume, batterie, alarme, applications, caméra, paramètres, appel
  Speaker.kt        – synthèse vocale (choisit une voix hors ligne si possible)
  VoiceInput.kt     – reconnaissance vocale (sur l'appareil en priorité)
  History.kt        – historique local
  Lang.kt, Replies.kt – textes en trois langues
.github/workflows/android.yml – compilation automatique dans le cloud
docs/TESTS.md       – tableau des tests à remplir sur le Redmi 12
```

## 🗣 Langues

Les phrases haoussa et arabes sont des **premières versions** : elles doivent être relues par des
locuteurs natifs. Pour ajouter une façon de dire une commande, modifier les listes dans `CommandEngine.kt`.
