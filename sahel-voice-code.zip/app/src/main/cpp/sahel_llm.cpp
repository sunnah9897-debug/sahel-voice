// Pont JNI entre Sahel Voice (Kotlin) et llama.cpp (IA locale, sans Internet).
#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>

#include "llama.h"

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SahelLLM", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

namespace {

struct Engine {
    llama_model * model = nullptr;
    int threads = 4;
};

std::once_flag g_backend_once;

// Codes d'erreur renvoyés à Kotlin (valeurs négatives).
constexpr int ERR_TEMPLATE = -1;
constexpr int ERR_CONTEXT = -2;
constexpr int ERR_TOO_LONG = -3;
constexpr int ERR_DECODE = -4;
constexpr int ERR_TOKENIZE = -5;

std::string jstring_to_utf8(JNIEnv * env, jstring s) {
    // Passe par getBytes("UTF-8") pour gérer correctement tous les caractères (accents, emojis).
    if (s == nullptr) return {};
    jclass str_cls = env->FindClass("java/lang/String");
    jmethodID get_bytes = env->GetMethodID(str_cls, "getBytes", "(Ljava/lang/String;)[B");
    jstring enc = env->NewStringUTF("UTF-8");
    auto arr = (jbyteArray) env->CallObjectMethod(s, get_bytes, enc);
    env->DeleteLocalRef(enc);
    env->DeleteLocalRef(str_cls);
    if (arr == nullptr) return {};
    jsize len = env->GetArrayLength(arr);
    std::string out(static_cast<size_t>(len), '\0');
    env->GetByteArrayRegion(arr, 0, len, reinterpret_cast<jbyte *>(&out[0]));
    env->DeleteLocalRef(arr);
    return out;
}

bool send_bytes(JNIEnv * env, jobject sink, jmethodID on_bytes, const char * data, size_t n) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(n));
    env->SetByteArrayRegion(arr, 0, static_cast<jsize>(n), reinterpret_cast<const jbyte *>(data));
    jboolean keep = env->CallBooleanMethod(sink, on_bytes, arr);
    env->DeleteLocalRef(arr);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }
    return keep == JNI_TRUE;
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_sahelvoice_app_LocalLlm_nativeLoad(JNIEnv * env, jobject /*thiz*/, jstring jpath, jint threads) {
    std::call_once(g_backend_once, [] { llama_backend_init(); });
    std::string path = jstring_to_utf8(env, jpath);

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;   // téléphone : CPU uniquement

    llama_model * model = llama_model_load_from_file(path.c_str(), mp);
    if (model == nullptr) {
        LOGI("echec du chargement du modele: %s", path.c_str());
        return 0;
    }
    auto * e = new Engine();
    e->model = model;
    e->threads = threads > 0 ? threads : 4;
    return reinterpret_cast<jlong>(e);
}

extern "C" JNIEXPORT void JNICALL
Java_com_sahelvoice_app_LocalLlm_nativeFree(JNIEnv * /*env*/, jobject /*thiz*/, jlong handle) {
    auto * e = reinterpret_cast<Engine *>(handle);
    if (e == nullptr) return;
    if (e->model != nullptr) llama_model_free(e->model);
    delete e;
}

/**
 * Génère une réponse.
 * roles/contents : la conversation (system, user, assistant…).
 * Chaque morceau de texte produit est envoyé à sink.onBytes(byte[]) ; si la méthode
 * renvoie false, la génération s'arrête.
 * Renvoie le nombre de jetons produits, ou un code d'erreur négatif.
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_sahelvoice_app_LocalLlm_nativeGenerate(
        JNIEnv * env, jobject /*thiz*/, jlong handle,
        jobjectArray jroles, jobjectArray jcontents,
        jint n_ctx, jint max_tokens, jobject sink) {

    auto * e = reinterpret_cast<Engine *>(handle);
    if (e == nullptr || e->model == nullptr) return ERR_CONTEXT;

    jclass sink_cls = env->GetObjectClass(sink);
    jmethodID on_bytes = env->GetMethodID(sink_cls, "onBytes", "([B)Z");
    env->DeleteLocalRef(sink_cls);
    if (on_bytes == nullptr) {
        env->ExceptionClear();
        return ERR_CONTEXT;
    }

    // 1. Mise en forme de la conversation avec le modèle de dialogue du fichier GGUF.
    const jsize n_msg = env->GetArrayLength(jroles);
    std::vector<std::string> roles, contents;
    roles.reserve(n_msg);
    contents.reserve(n_msg);
    size_t total = 0;
    for (jsize i = 0; i < n_msg; i++) {
        auto r = (jstring) env->GetObjectArrayElement(jroles, i);
        auto c = (jstring) env->GetObjectArrayElement(jcontents, i);
        roles.push_back(jstring_to_utf8(env, r));
        contents.push_back(jstring_to_utf8(env, c));
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
        total += roles.back().size() + contents.back().size();
    }
    std::vector<llama_chat_message> msgs;
    msgs.reserve(n_msg);
    for (jsize i = 0; i < n_msg; i++) msgs.push_back({roles[i].c_str(), contents[i].c_str()});

    const char * tmpl = llama_model_chat_template(e->model, nullptr);
    if (tmpl == nullptr) tmpl = "chatml";
    std::vector<char> buf(total * 2 + 1024);
    int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    if (len > (int32_t) buf.size()) {
        buf.resize(len + 1);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
    }
    if (len < 0) {
        // Modèle de dialogue inconnu : on essaie le format le plus courant.
        len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        if (len > (int32_t) buf.size()) {
            buf.resize(len + 1);
            len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        }
        if (len < 0) return ERR_TEMPLATE;
    }
    const std::string prompt(buf.data(), (size_t) len);

    // 2. Découpage en jetons.
    const llama_vocab * vocab = llama_model_get_vocab(e->model);
    int32_t n_prompt = -llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0) return ERR_TOKENIZE;
    std::vector<llama_token> tokens((size_t) n_prompt);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), tokens.data(), n_prompt, true, true) < 0) {
        return ERR_TOKENIZE;
    }
    if (n_prompt + 16 > n_ctx) return ERR_TOO_LONG;

    // 3. Contexte de calcul (recréé à chaque réponse : simple et sûr).
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) n_ctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = e->threads;
    cp.n_threads_batch = e->threads;
    llama_context * ctx = llama_init_from_model(e->model, cp);
    if (ctx == nullptr) return ERR_CONTEXT;

    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(vocab), 64, 1.1f, 0.0f, 0.0f));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int result = 0;
    // 4. Lecture de la question par blocs.
    for (int32_t i = 0; i < n_prompt; i += 512) {
        int32_t n = std::min<int32_t>(512, n_prompt - i);
        if (llama_decode(ctx, llama_batch_get_one(tokens.data() + i, n)) != 0) {
            result = ERR_DECODE;
            break;
        }
    }

    // 5. Production de la réponse, jeton par jeton.
    if (result == 0) {
        int produced = 0;
        int pos = n_prompt;
        char piece[256];
        while (produced < max_tokens && pos < n_ctx) {
            llama_token tok = llama_sampler_sample(smpl, ctx, -1);
            if (llama_vocab_is_eog(vocab, tok)) break;
            int32_t n = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, false);
            if (n > 0 && !send_bytes(env, sink, on_bytes, piece, (size_t) n)) {
                produced++;
                break; // arrêt demandé par l'utilisateur
            }
            produced++;
            if (llama_decode(ctx, llama_batch_get_one(&tok, 1)) != 0) {
                result = ERR_DECODE;
                break;
            }
            pos++;
        }
        if (result == 0) result = produced;
    }

    llama_sampler_free(smpl);
    llama_free(ctx);
    return result;
}
