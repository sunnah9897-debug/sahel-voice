package com.sahelvoice.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Couleurs : vert du Sahel et sable / ocre.
private val Light = lightColorScheme(
    primary = Color(0xFF1F6F5C),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBE1),
    onPrimaryContainer = Color(0xFF00201A),
    secondary = Color(0xFFB8641A),
    onSecondary = Color.White,
    background = Color(0xFFFBF7F0),
    onBackground = Color(0xFF1C1B18),
    surface = Color(0xFFFBF7F0),
    onSurface = Color(0xFF1C1B18),
    surfaceVariant = Color(0xFFEFE7DA),
    onSurfaceVariant = Color(0xFF4A453D),
    errorContainer = Color(0xFFFCDAD3),
    onErrorContainer = Color(0xFF3B0A02),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF7AD5BC),
    onPrimary = Color(0xFF00382D),
    primaryContainer = Color(0xFF1F5246),
    onPrimaryContainer = Color(0xFFCDEBE1),
    secondary = Color(0xFFF0B060),
    onSecondary = Color(0xFF462A00),
    background = Color(0xFF111816),
    onBackground = Color(0xFFE6E2DA),
    surface = Color(0xFF111816),
    onSurface = Color(0xFFE6E2DA),
    surfaceVariant = Color(0xFF26302D),
    onSurfaceVariant = Color(0xFFC6C1B6),
    errorContainer = Color(0xFF5C1A0E),
    onErrorContainer = Color(0xFFFCDAD3),
)

@Composable
fun SahelTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
