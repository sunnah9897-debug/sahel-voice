package com.sahelvoice.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Écoute en arrière-plan : attend le mot « Sahel » (ou « Assistant »), puis écoute
 * une commande et l'exécute, sans ouvrir l'application.
 * Une notification reste visible tant que l'écoute est active (obligatoire sur Android).
 * Tout se fait hors ligne (Vosk), sans Internet.
 */
class ListenService : Service() {

    companion object {
        const val ACTION_START = "com.sahelvoice.app.START_LISTEN"
        const val ACTION_STOP = "com.sahelvoice.app.STOP_LISTEN"
        private const val CHANNEL = "sahel_listen"
        private const val NOTIF_ID = 42
        private const val RATE = 16000

        /** true quand l'écran de Sahel Voice est affiché : le service laisse alors le micro à l'écran. */
        @Volatile var appInForeground = false

        fun start(ctx: Context) {
            val i = Intent(ctx, ListenService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            try {
                ctx.startService(Intent(ctx, ListenService::class.java).setAction(ACTION_STOP))
            } catch (_: Throwable) {
            }
        }
    }

    private enum class Mode { WAKE, COMMAND, BUSY }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var mode = Mode.BUSY
    @Volatile private var resetWake = false
    @Volatile private var resetCommand = false
    private var audioThread: Thread? = null
    private var model: Model? = null
    private var wakeRec: Recognizer? = null
    private var cmdRec: Recognizer? = null
    private var speaker: Speaker? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var tone: ToneGenerator? = null
    private lateinit var phone: PhoneActions

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        try {
            goForeground("Préparation de l'écoute…")
        } catch (e: Throwable) {
            WakeStatus.line = "Android a refusé l'écoute en arrière-plan : ${e.message}"
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        WakeStatus.running = true
        phone = PhoneActions(this)
        speaker = Speaker(this, onReady = {}, onSpeakError = {})
        tone = try {
            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
        } catch (_: Throwable) {
            null
        }
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SahelVoice:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
        audioThread = Thread({ listenLoop() }, "sahel-listen").also { it.start() }
        return START_NOT_STICKY
    }

    // ---------- Notification ----------

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Écoute Sahel Voice", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Indique que Sahel Voice écoute le mot d'activation"
                    setShowBadge(false)
                },
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sahel Voice écoute")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openApp)
            .addAction(0, "Arrêter l'écoute", stop)
            .build()
    }

    private fun goForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(text), type)
    }

    private fun updateStatus(text: String) {
        main.post {
            if (!running) return@post
            WakeStatus.line = text
            try {
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .notify(NOTIF_ID, buildNotification(text))
            } catch (_: Throwable) {
            }
        }
    }

    // ---------- Écoute ----------

    @SuppressLint("MissingPermission")
    private fun listenLoop() {
        var recorder: AudioRecord? = null
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                fatal("Le micro n'est pas autorisé. Ouvrez Sahel Voice et touchez 🎤 une fois.")
                return
            }
            if (!WakeModel.installed(this)) {
                fatal("Le modèle de mot d'activation n'est pas installé (menu ⚡).")
                return
            }
            try {
                LibVosk.setLogLevel(LogLevel.WARNINGS)
            } catch (_: Throwable) {
            }
            val m = Model(WakeModel.dir(this).absolutePath)
            model = m
            val grammar = "[\"" + WakeModel.WAKE_WORDS.joinToString("\", \"") + "\", \"[unk]\"]"
            wakeRec = Recognizer(m, RATE.toFloat(), grammar)
            cmdRec = Recognizer(m, RATE.toFloat())

            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, RATE),
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                fatal("Impossible d'utiliser le micro (il est peut-être utilisé par une autre application).")
                return
            }
            recorder.startRecording()
            mode = Mode.WAKE
            updateStatus("Dites ${WakeModel.wakeHint(this)}, attendez le bip, puis votre commande.")

            val buf = ShortArray(RATE / 4) // 0,25 s
            var cmdSamples = 0
            while (running) {
                // Quand l'écran de Sahel Voice est ouvert, on libère le micro pour lui.
                if (appInForeground) {
                    if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop()
                    Thread.sleep(200)
                    continue
                } else if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    recorder.startRecording()
                    resetWake = true
                    if (mode == Mode.COMMAND) mode = Mode.WAKE
                }
                val n = recorder.read(buf, 0, buf.size)
                if (n <= 0) continue
                when (mode) {
                    Mode.WAKE -> {
                        val rec = wakeRec ?: break
                        if (resetWake) {
                            rec.reset()
                            resetWake = false
                        }
                        val final = rec.acceptWaveForm(buf, n)
                        val text = if (final) field(rec.result, "text") else field(rec.partialResult, "partial")
                        if (WakeModel.WAKE_WORDS.any { w -> text.split(" ").contains(w) }) {
                            rec.reset()
                            mode = Mode.COMMAND
                            resetCommand = true
                            cmdSamples = 0
                            beep()
                            updateStatus("Je vous écoute…")
                        }
                    }
                    Mode.COMMAND -> {
                        val rec = cmdRec ?: break
                        if (resetCommand) {
                            rec.reset()
                            resetCommand = false
                        }
                        cmdSamples += n
                        if (cmdSamples < RATE * 3 / 10) continue // on ignore le bip
                        if (rec.acceptWaveForm(buf, n)) {
                            val text = field(rec.result, "text")
                            if (text.isNotBlank()) {
                                mode = Mode.BUSY
                                main.post { handleCommand(text) }
                            }
                        } else if (cmdSamples > RATE * 7) {
                            val text = field(rec.finalResult, "text")
                            mode = Mode.BUSY
                            main.post { handleCommand(text) }
                        }
                    }
                    Mode.BUSY -> Unit // pendant que Sahel Voice parle, on n'écoute pas sa propre voix
                }
            }
        } catch (e: Throwable) {
            fatal("L'écoute s'est arrêtée : ${e.message}")
        } finally {
            try {
                recorder?.stop()
            } catch (_: Throwable) {
            }
            try {
                recorder?.release()
            } catch (_: Throwable) {
            }
            try {
                wakeRec?.close()
                cmdRec?.close()
                model?.close()
            } catch (_: Throwable) {
            }
            wakeRec = null
            cmdRec = null
            model = null
        }
    }

    private fun field(json: String?, key: String): String = try {
        JSONObject(json ?: "{}").optString(key, "").trim()
    } catch (_: Throwable) {
        ""
    }

    private fun beep() {
        try {
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (_: Throwable) {
        }
    }

    private fun fatal(msg: String) {
        main.post {
            WakeStatus.line = "⚠ $msg"
            shutdown()
        }
    }

    /** Retour à l'attente du mot d'activation. */
    private fun backToWake() {
        if (!running) return
        resetWake = true
        mode = Mode.WAKE
        updateStatus("Dites ${WakeModel.wakeHint(this)}, attendez le bip, puis votre commande.")
    }

    /** Dit une phrase, puis reprend l'écoute du mot d'activation. */
    private fun say(text: String) {
        updateStatus("Réponse : $text")
        val sp = speaker
        if (sp == null) {
            backToWake()
            return
        }
        sp.onIdle = {
            sp.onIdle = null
            main.postDelayed({ backToWake() }, 300)
        }
        if (!sp.speak(text, Lang.FR)) {
            sp.onIdle = null
            backToWake()
        }
    }

    // ---------- Commandes ----------

    private fun canOpenScreens(): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    private val needOverlay =
        "Pour ouvrir une application pendant que je suis en arrière-plan, autorisez « Afficher par-dessus les autres applications » dans le menu éclair de Sahel Voice."

    private fun handleCommand(raw: String) {
        if (!running) return
        val text = raw.trim()
        if (text.isEmpty()) {
            say("Je n'ai rien entendu.")
            return
        }
        updateStatus("Vous : $text")
        val fr = Lang.FR
        try {
            val parsed = CommandEngine.parse(text, fr)
            val reply: String? = when (val c = parsed.cmd) {
                Cmd.StopSpeaking -> {
                    speaker?.stop()
                    ChatEngine.current()?.stop()
                    null
                }
                Cmd.Repeat -> "Je ne peux pas répéter en arrière-plan."
                Cmd.ClearHistory -> "Pour effacer la conversation, ouvrez Sahel Voice."
                Cmd.TorchOn -> phone.torch(true).text[fr]
                Cmd.TorchOff -> phone.torch(false).text[fr]
                Cmd.VolumeUp -> phone.volume(true).text[fr]
                Cmd.VolumeDown -> phone.volume(false).text[fr]
                Cmd.Battery -> phone.battery().text[fr]
                Cmd.Time -> {
                    val cal = Calendar.getInstance()
                    Replies.time(String.format(Locale.ROOT, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)))[fr]
                }
                Cmd.Date -> {
                    val d = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(Date())
                    Replies.date(d, d, d)[fr]
                }
                Cmd.Help -> "Dites par exemple : allume la lampe, quelle heure est-il, augmente le volume, ouvre WhatsApp."
                Cmd.Greeting -> Replies.greeting[fr]
                Cmd.Thanks -> Replies.thanks[fr]
                Cmd.Camera -> if (canOpenScreens()) phone.camera().text[fr] else needOverlay
                Cmd.Settings -> if (canOpenScreens()) phone.settings().text[fr] else needOverlay
                is Cmd.OpenApp -> if (canOpenScreens()) phone.openApp(c.name).text[fr] else needOverlay
                is Cmd.Dial -> if (canOpenScreens()) phone.dial(c.number).text[fr] else needOverlay
                is Cmd.Alarm -> {
                    val h = c.hour
                    when {
                        h == null -> Replies.alarmNoTime[fr]
                        !canOpenScreens() -> needOverlay
                        else -> phone.alarm(h, c.minute, String.format(Locale.ROOT, "%02d:%02d", h, c.minute)).text[fr]
                    }
                }
                Cmd.Unknown -> {
                    askAi(text)
                    return
                }
            }
            if (reply == null) backToWake() else say(reply)
        } catch (e: Throwable) {
            say("Désolé, une erreur est survenue.")
        }
    }

    /** Question libre : l'IA répond si elle est déjà chargée dans le téléphone. */
    private fun askAi(question: String) {
        val chat = ChatEngine.current()
        if (chat == null || chat.state != AiState.READY || chat.generating) {
            say("Je n'ai pas compris. Pour discuter librement, ouvrez Sahel Voice.")
            return
        }
        updateStatus("L'IA réfléchit…")
        chat.ask(question, onPartial = {}, onDone = { answer, error ->
            say(answer ?: error ?: "Je n'ai pas de réponse.")
        })
    }

    // ---------- Arrêt ----------

    private fun shutdown() {
        running = false
        WakeStatus.running = false
        try {
            audioThread?.join(1500)
        } catch (_: Throwable) {
        }
        audioThread = null
        try {
            speaker?.shutdown()
        } catch (_: Throwable) {
        }
        speaker = null
        try {
            tone?.release()
        } catch (_: Throwable) {
        }
        tone = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {
        }
        wakeLock = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown()
        super.onDestroy()
    }
}
