package com.sahelvoice.app

import java.text.Normalizer

/** Commandes comprises par l'assistant. */
sealed class Cmd {
    data object StopSpeaking : Cmd()
    data object Repeat : Cmd()
    data object ClearHistory : Cmd()
    data object TorchOn : Cmd()
    data object TorchOff : Cmd()
    data object VolumeUp : Cmd()
    data object VolumeDown : Cmd()
    data object Battery : Cmd()
    data object Date : Cmd()
    data object Time : Cmd()
    data object Camera : Cmd()
    data object Settings : Cmd()
    data object Help : Cmd()
    data object Greeting : Cmd()
    data object Thanks : Cmd()
    data class Alarm(val hour: Int?, val minute: Int) : Cmd()
    data class Dial(val number: String?) : Cmd()
    data class OpenApp(val name: String) : Cmd()
    data object Unknown : Cmd()
}

/** Résultat de l'analyse : la commande et la langue dans laquelle elle a été dite. */
data class Parsed(val cmd: Cmd, val lang: Lang?)

/**
 * Met un texte sous une forme simple pour la comparaison :
 * minuscules, sans accents ni voyelles arabes, lettres haoussa simplifiées,
 * chiffres arabes convertis, ponctuation supprimée.
 */
fun normalizeText(input: String): String {
    var t = input.lowercase()
    t = t.replace('ɓ', 'b').replace('ɗ', 'd').replace('ƙ', 'k').replace('ƴ', 'y')
    t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
    val sb = StringBuilder(t.length)
    for (c in t) {
        val mapped = when (c) {
            in '٠'..'٩' -> '0' + (c - '٠')
            in '۰'..'۹' -> '0' + (c - '۰')
            'أ', 'إ', 'آ', 'ٱ' -> 'ا'
            'ى' -> 'ي'
            'ة' -> 'ه'
            'ؤ' -> 'و'
            'ئ' -> 'ي'
            'ـ' -> ' '
            else -> c
        }
        sb.append(mapped)
    }
    t = sb.toString()
    t = t.replace(Regex("[^\\p{L}\\p{N}: ]"), " ")
    return t.replace(Regex("\\s+"), " ").trim()
}

/** Liste de mots-clés par langue. */
private class Kw(fr: List<String>, ar: List<String>, ha: List<String>) {
    val byLang: List<Pair<Lang, List<String>>> = listOf(
        Lang.FR to fr.map { normalizeText(it) },
        Lang.AR to ar.map { normalizeText(it) },
        Lang.HA to ha.map { normalizeText(it) },
    )

    /** Renvoie la langue du premier mot-clé trouvé (mot entier), ou null. */
    fun find(padded: String): Lang? {
        for ((lang, list) in byLang) {
            if (list.any { it.isNotEmpty() && padded.contains(" $it ") }) return lang
        }
        return null
    }

    fun all(): List<String> = byLang.flatMap { it.second }
}

object CommandEngine {

    private val STOP = Kw(
        listOf("arrete de parler", "arrete", "tais toi", "silence", "stop", "chut"),
        listOf("توقف عن الكلام", "توقف", "اسكت", "قف", "كفى"),
        listOf("dakatar da magana", "dakata", "yi shiru", "tsaya", "isa haka"),
    )
    private val REPEAT = Kw(
        listOf("repete", "repeter", "redis", "encore une fois"),
        listOf("كرر", "اعد", "مره اخرى"),
        listOf("maimaita", "sake fada"),
    )
    private val CLEAR_VERB = Kw(
        listOf("efface", "effacer", "supprime", "supprimer", "vide"),
        listOf("امسح", "احذف", "مسح", "حذف"),
        listOf("share", "goge", "cire"),
    )
    private val CLEAR_OBJ = Kw(
        listOf("conversation", "historique", "discussion"),
        listOf("المحادثه", "محادثه", "السجل", "سجل"),
        listOf("hira", "tarihi", "tarihin hira", "tattaunawa"),
    )
    private val LAMP = Kw(
        listOf("lampe", "torche", "flash", "lumiere", "lampe torche"),
        listOf("المصباح", "مصباح", "الكشاف", "كشاف", "الفلاش", "فلاش", "الضوء", "ضوء"),
        listOf("fitila", "fitilar", "tocila", "toci", "haske", "fulash"),
    )
    private val OFF = Kw(
        listOf("eteins", "eteindre", "eteint", "eteignez", "coupe", "desactive", "arrete"),
        listOf("اطفي", "اطف", "طفي", "اغلق", "سكر", "اوقف"),
        listOf("kashe", "rufe"),
    )
    private val ALARM = Kw(
        listOf("alarme", "reveil", "reveille moi", "reveiller"),
        listOf("منبه", "منبها", "المنبه", "منبهه", "ايقظني", "صحيني"),
        listOf("kararrawa", "kararrawar", "agogon kararrawa", "tashe ni"),
    )
    private val VOL_WORD = Kw(
        listOf("volume", "son"),
        listOf("الصوت", "صوت", "مستوى الصوت"),
        listOf("sauti", "karar sauti"),
    )
    private val VOL_UP = Kw(
        listOf("augmente", "augmenter", "monte", "monter", "hausse", "plus fort", "plus"),
        listOf("ارفع", "رفع", "زد", "زود", "علي", "اعلى"),
        listOf("kara", "daga"),
    )
    private val VOL_DOWN = Kw(
        listOf("baisse", "baisser", "diminue", "diminuer", "reduis", "moins fort", "moins"),
        listOf("اخفض", "خفض", "قلل", "نزل", "اخفض"),
        listOf("rage", "sauke"),
    )
    private val LOUDER = Kw(listOf("plus fort"), listOf("بصوت اعلى"), listOf())
    private val SOFTER = Kw(listOf("moins fort"), listOf("بصوت اخفض"), listOf())
    private val BATTERY = Kw(
        listOf("batterie", "charge"),
        listOf("البطاريه", "بطاريه", "الشحن", "شحن"),
        listOf("batir", "batiri", "batirin", "caji"),
    )
    private val TIME = Kw(
        listOf("quelle heure", "l heure", "heure est il", "heure"),
        listOf("كم الساعه", "الساعه كم", "الوقت", "كم الوقت"),
        listOf("karfe nawa", "lokaci", "lokacin"),
    )
    private val DATE = Kw(
        listOf("date", "quel jour", "jour sommes", "on est quel jour"),
        listOf("التاريخ", "تاريخ", "اي يوم", "ما اليوم", "اليوم"),
        listOf("kwanan wata", "wace rana", "rana nawa", "yau"),
    )
    private val CAMERA = Kw(
        listOf("camera", "appareil photo", "photo"),
        listOf("الكاميرا", "كاميرا", "التصوير"),
        listOf("kyamara", "kamara", "hoto"),
    )
    private val SETTINGS = Kw(
        listOf("parametres", "parametre", "reglages", "reglage"),
        listOf("الاعدادات", "اعدادات", "الضبط"),
        listOf("saituna", "saitunan", "seti"),
    )
    private val DIAL = Kw(
        listOf("appelle", "appeler", "appel", "compose", "telephone", "composeur"),
        listOf("اتصل", "اتصال", "الهاتف", "هاتف", "كلم"),
        listOf("kira", "kiran", "waya"),
    )
    private val HELP = Kw(
        listOf("aide", "aide moi", "que sais tu faire", "commandes"),
        listOf("مساعده", "ساعدني", "ماذا تستطيع"),
        listOf("taimako", "taimake ni", "me za ka iya"),
    )
    private val GREETING = Kw(
        listOf("bonjour", "bonsoir", "salut", "salam", "assalamou alaikoum"),
        listOf("السلام عليكم", "السلام", "مرحبا", "اهلا"),
        listOf("sannu", "barka", "ina kwana", "ina wuni", "salamu alaikum", "assalamu alaikum"),
    )
    private val THANKS = Kw(
        listOf("merci"),
        listOf("شكرا", "جزاك الله"),
        listOf("na gode", "nagode", "godiya"),
    )
    private val OPEN = Kw(
        listOf("ouvre", "ouvrir", "ouvrez", "lance", "lancer", "demarre", "demarrer", "va sur", "affiche"),
        listOf("افتح", "افتحي", "شغل", "شغلي", "تشغيل", "اذهب الى"),
        listOf("bude", "kunna", "shiga"),
    )
    private val FILLERS = Kw(
        listOf(
            "s il te plait", "s il vous plait", "stp", "svp", "l application", "application",
            "l appli", "appli", "le", "la", "les", "l", "mon", "ma", "moi", "pour", "sur",
        ),
        listOf("من فضلك", "لو سمحت", "التطبيق", "تطبيق", "البرنامج", "برنامج", "لي"),
        listOf("don allah", "manhajar", "manhaja", "app", "mini", "min", "ta", "na"),
    )

    fun parse(raw: String, fallback: Lang): Parsed {
        val t = normalizeText(raw)
        if (t.isEmpty()) return Parsed(Cmd.Unknown, null)
        val p = " $t "
        val arabicScript = raw.any { it in '؀'..'ۿ' }
        val guess = if (arabicScript) Lang.AR else fallback

        // 1. Contrôle de la parole et de l'historique.
        CLEAR_VERB.find(p)?.let { l -> if (CLEAR_OBJ.find(p) != null) return Parsed(Cmd.ClearHistory, l) }
        LAMP.find(p)?.let { l ->
            return if (OFF.find(p) != null) Parsed(Cmd.TorchOff, l) else Parsed(Cmd.TorchOn, l)
        }
        STOP.find(p)?.let { return Parsed(Cmd.StopSpeaking, it) }
        REPEAT.find(p)?.let { return Parsed(Cmd.Repeat, it) }

        // 2. Alarme (avant l'heure, car « alarme à six heures » contient « heure »).
        ALARM.find(p)?.let { l ->
            val tm = TimeParser.parse(t)
            return Parsed(Cmd.Alarm(tm?.first, tm?.second ?: 0), l)
        }

        // 3. Volume.
        LOUDER.find(p)?.let { return Parsed(Cmd.VolumeUp, it) }
        SOFTER.find(p)?.let { return Parsed(Cmd.VolumeDown, it) }
        VOL_WORD.find(p)?.let { l ->
            if (VOL_DOWN.find(p) != null) return Parsed(Cmd.VolumeDown, l)
            if (VOL_UP.find(p) != null) return Parsed(Cmd.VolumeUp, l)
        }

        // 4. Informations.
        BATTERY.find(p)?.let { return Parsed(Cmd.Battery, it) }
        TIME.find(p)?.let { return Parsed(Cmd.Time, it) }
        DATE.find(p)?.let { return Parsed(Cmd.Date, it) }

        // 5. Écrans du téléphone.
        CAMERA.find(p)?.let { return Parsed(Cmd.Camera, it) }
        SETTINGS.find(p)?.let { return Parsed(Cmd.Settings, it) }
        DIAL.find(p)?.let { l ->
            val digits = t.filter { it.isDigit() }
            return Parsed(Cmd.Dial(if (digits.length >= 3) digits else null), l)
        }

        // 6. Ouverture d'une application.
        val openLang = OPEN.find(p)
        if (openLang != null) {
            val name = stripWords(p, OPEN.all() + FILLERS.all())
            return Parsed(Cmd.OpenApp(name), openLang)
        }
        AppAliases.canonical(t)?.let { return Parsed(Cmd.OpenApp(t), guess) }

        // 7. Politesse et aide.
        HELP.find(p)?.let { return Parsed(Cmd.Help, it) }
        GREETING.find(p)?.let { return Parsed(Cmd.Greeting, it) }
        THANKS.find(p)?.let { return Parsed(Cmd.Thanks, it) }

        return Parsed(Cmd.Unknown, if (arabicScript) Lang.AR else null)
    }

    /** Retire de la phrase les mots donnés (les plus longs d'abord). */
    private fun stripWords(padded: String, words: List<String>): String {
        var s = padded
        val sorted = words.filter { it.isNotEmpty() }.sortedByDescending { it.length }
        var changed = true
        while (changed) {
            changed = false
            for (w in sorted) {
                val before = s
                s = s.replace(" $w ", " ")
                if (s != before) changed = true
            }
        }
        return s.trim()
    }
}

/** Lecture d'une heure dite en français, en arabe ou en haoussa. */
object TimeParser {

    // Les expressions les plus longues d'abord.
    private val WORDS: List<Pair<String, Int>> = listOf(
        // Français
        "vingt trois" to 23, "vingt deux" to 22, "vingt et une" to 21, "vingt" to 20,
        "dix neuf" to 19, "dix huit" to 18, "dix sept" to 17, "seize" to 16, "quinze" to 15,
        "quatorze" to 14, "treize" to 13, "douze" to 12, "onze" to 11, "dix" to 10,
        "neuf" to 9, "huit" to 8, "sept" to 7, "six" to 6, "cinq" to 5, "quatre" to 4,
        "trois" to 3, "deux" to 2, "une heure" to 1, "midi" to 12, "minuit" to 0,
        // Arabe (ordinaux féminins et nombres)
        "الحاديه عشره" to 11, "الحاديه عشر" to 11, "الثانيه عشره" to 12, "الثانيه عشر" to 12,
        "الواحده" to 1, "الثانيه" to 2, "الثالثه" to 3, "الرابعه" to 4, "الخامسه" to 5,
        "السادسه" to 6, "السابعه" to 7, "الثامنه" to 8, "التاسعه" to 9, "العاشره" to 10,
        "واحده" to 1, "اثنين" to 2, "ثلاثه" to 3, "اربعه" to 4, "خمسه" to 5, "سته" to 6,
        "سبعه" to 7, "ثمانيه" to 8, "تسعه" to 9, "عشره" to 10,
        // Haoussa
        "goma sha daya" to 11, "goma sha biyu" to 12, "daya" to 1, "biyu" to 2, "uku" to 3,
        "hudu" to 4, "biyar" to 5, "shida" to 6, "bakwai" to 7, "takwas" to 8, "tara" to 9,
        "goma" to 10,
    ).map { normalizeText(it.first) to it.second }.sortedByDescending { it.first.length }

    private val HALF = listOf("et demie", "et demi", "والنصف", "و نصف", "ونصف", "da rabi").map { normalizeText(it) }
    private val QUARTER = listOf("et quart", "والربع", "وربع", "da kwata").map { normalizeText(it) }
    private val TO_QUARTER = listOf("moins le quart", "moins quart", "الا ربع", "الا الربع", "saura kwata").map { normalizeText(it) }
    private val EVENING = listOf(
        "du soir", "de l apres midi", "apres midi", "soir", "مساء", "مساءا", "ليلا", "بالليل",
        "na yamma", "da yamma", "da dare", "na dare",
    ).map { normalizeText(it) }

    /** Renvoie (heure, minute) ou null si aucune heure n'est trouvée. */
    fun parse(normalized: String): Pair<Int, Int>? {
        val p = " $normalized "
        var hour: Int? = null
        var minute = 0

        val hm = Regex("(\\d{1,2})\\s*(?:heures?|h|:)\\s*(\\d{1,2})?").find(normalized)
        if (hm != null) {
            hour = hm.groupValues[1].toInt()
            minute = hm.groupValues[2].toIntOrNull() ?: 0
        } else {
            Regex("(?<!\\d)(\\d{1,2})(?!\\d)").find(normalized)?.let { hour = it.groupValues[1].toInt() }
        }
        if (hour == null) {
            for ((w, v) in WORDS) {
                if (p.contains(" $w ")) { hour = v; break }
            }
        }
        var h = hour ?: return null

        if (HALF.any { p.contains(" $it ") }) minute = 30
        if (QUARTER.any { p.contains(" $it ") }) minute = 15
        if (TO_QUARTER.any { p.contains(" $it ") }) { h -= 1; minute = 45 }
        if (h < 12 && EVENING.any { p.contains(" $it ") }) h += 12
        if (h < 0) h += 24
        if (h !in 0..23 || minute !in 0..59) return null
        return h to minute
    }
}

/** Noms d'applications connus, dits en plusieurs langues. */
object AppAliases {
    /** nom canonique -> (façons de le dire, paquets Android connus, libellés possibles) */
    private data class App(val spoken: List<String>, val packages: List<String>, val labels: List<String>)

    private val APPS: Map<String, App> = mapOf(
        "WhatsApp" to App(
            listOf("whatsapp", "whats app", "watsap", "wasap", "watsapp", "واتساب", "واتس اب", "واتس", "الواتساب", "wassap"),
            listOf("com.whatsapp", "com.whatsapp.w4b"), listOf("whatsapp"),
        ),
        "YouTube" to App(
            listOf("youtube", "you tube", "yutub", "youtub", "يوتيوب", "اليوتيوب"),
            listOf("com.google.android.youtube"), listOf("youtube"),
        ),
        "Facebook" to App(
            listOf("facebook", "face book", "fesbuk", "فيسبوك", "فيس بوك", "الفيسبوك"),
            listOf("com.facebook.katana", "com.facebook.lite"), listOf("facebook", "lite"),
        ),
        "TikTok" to App(
            listOf("tiktok", "tik tok", "تيك توك", "تيكتوك"),
            listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"), listOf("tiktok"),
        ),
        "Chrome" to App(
            listOf("chrome", "google chrome", "كروم", "جوجل كروم"),
            listOf("com.android.chrome"), listOf("chrome"),
        ),
        "Telegram" to App(
            listOf("telegram", "تلغرام", "تيليجرام", "تليجرام"),
            listOf("org.telegram.messenger"), listOf("telegram"),
        ),
        "Messages" to App(
            listOf("messages", "sms", "الرسائل", "رسائل", "sakonni", "sako"),
            listOf("com.google.android.apps.messaging", "com.android.mms"), listOf("messages", "messagerie"),
        ),
        "Calculatrice" to App(
            listOf("calculatrice", "calculette", "الحاسبه", "الاله الحاسبه", "na urar lissafi", "lissafi"),
            listOf("com.miui.calculator", "com.google.android.calculator"), listOf("calculatrice", "calculator"),
        ),
        "Galerie" to App(
            listOf("galerie", "photos", "المعرض", "الصور", "hotuna"),
            listOf("com.miui.gallery", "com.google.android.apps.photos"), listOf("galerie", "gallery", "photos"),
        ),
        "Horloge" to App(
            listOf("horloge", "الساعه", "agogo"),
            listOf("com.android.deskclock", "com.google.android.deskclock"), listOf("horloge", "clock"),
        ),
        "Play Store" to App(
            listOf("play store", "playstore", "store", "بلاي ستور", "المتجر"),
            listOf("com.android.vending"), listOf("play store"),
        ),
    ).mapValues { (_, a) -> a.copy(spoken = a.spoken.map { normalizeText(it) }, labels = a.labels.map { normalizeText(it) }) }

    /** Nom canonique si le texte complet correspond à une application connue. */
    fun canonical(normalized: String): String? =
        APPS.entries.firstOrNull { (_, a) -> a.spoken.any { it == normalized } }?.key

    /** Nom canonique si le texte contient le nom d'une application connue. */
    fun find(normalized: String): String? {
        val p = " $normalized "
        return APPS.entries.firstOrNull { (_, a) -> a.spoken.any { p.contains(" $it ") } }?.key
    }

    fun packagesFor(canonical: String): List<String> = APPS[canonical]?.packages ?: emptyList()
    fun labelsFor(canonical: String): List<String> = APPS[canonical]?.labels ?: emptyList()
}
