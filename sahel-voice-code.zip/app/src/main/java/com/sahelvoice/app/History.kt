package com.sahelvoice.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Type de message affiché. */
enum class Kind { USER, ACTION, INFO, ERROR }

data class Msg(
    val id: Long,
    val kind: Kind,
    val text: String,
    val lang: Lang,
)

/** Historique et réglages, enregistrés uniquement sur le téléphone. */
class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sahel_voice", Context.MODE_PRIVATE)

    fun load(): List<Msg> = try {
        val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Msg(
                id = o.getLong("id"),
                kind = Kind.valueOf(o.getString("kind")),
                text = o.getString("text"),
                lang = Lang.fromCode(o.optString("lang")),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Msg>) {
        val arr = JSONArray()
        list.takeLast(MAX).forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("kind", m.kind.name)
                    .put("text", m.text)
                    .put("lang", m.lang.code),
            )
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    var uiLang: Lang
        get() = Lang.fromCode(prefs.getString("ui_lang", "fr"))
        set(v) = prefs.edit().putString("ui_lang", v.code).apply()

    var ttsEnabled: Boolean
        get() = prefs.getBoolean("tts", true)
        set(v) = prefs.edit().putBoolean("tts", v).apply()

    companion object {
        private const val KEY_HISTORY = "history"
        const val MAX = 200
    }
}
