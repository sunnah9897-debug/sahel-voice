package com.sahelvoice.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.util.zip.ZipInputStream

/** État de l'écoute en arrière-plan, visible par l'écran. */
object WakeStatus {
    /** true quand le service d'écoute tourne. */
    var running by mutableStateOf(false)

    /** Ligne d'information (importation, erreurs, dernière commande…). */
    var line by mutableStateOf("")

    /** Change quand le modèle est installé ou supprimé. */
    var modelTick by mutableStateOf(0)
}

/**
 * Modèle Vosk français (vosk-model-small-fr-0.22, 41 Mo, Apache 2.0) utilisé pour
 * reconnaître le mot d'activation et les commandes en arrière-plan, sans Internet.
 */
object WakeModel {
    const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"

    /** Mots d'activation possibles (le premier est le principal). */
    val WAKE_WORDS = listOf("sahel", "assistant")

    private val main = Handler(Looper.getMainLooper())

    fun dir(ctx: Context) = File(ctx.filesDir, "vosk/model")

    private fun looksLikeModel(d: File) =
        File(d, "conf/model.conf").exists() || File(d, "am/final.mdl").exists()

    fun installed(ctx: Context): Boolean = looksLikeModel(dir(ctx))

    /**
     * Mot à dire pour réveiller Sahel Voice. Si « sahel » n'est pas dans le vocabulaire
     * du modèle, on utilise « assistant ».
     */
    fun wakeHint(ctx: Context): String {
        val words = File(dir(ctx), "graph/words.txt")
        if (!words.exists()) return "« Sahel » (ou « Assistant »)"
        return try {
            val hasSahel = words.useLines { lines -> lines.any { it.startsWith("sahel ") } }
            if (hasSahel) "« Sahel » (ou « Assistant »)" else "« Assistant »"
        } catch (e: Throwable) {
            "« Sahel » (ou « Assistant »)"
        }
    }

    fun delete(ctx: Context) {
        File(ctx.filesDir, "vosk").deleteRecursively()
        WakeStatus.modelTick++
    }

    /** Décompresse le fichier .zip choisi dans le stockage privé de l'application. */
    fun import(ctx: Context, uri: Uri) {
        val app = ctx.applicationContext
        WakeStatus.line = "Importation du modèle de mot d'activation…"
        Thread {
            val msg = try {
                importUnsafe(app, uri)
            } catch (e: Throwable) {
                "Erreur pendant l'importation : ${e.message}"
            }
            main.post {
                WakeStatus.line = msg
                WakeStatus.modelTick++
            }
        }.start()
    }

    private fun importUnsafe(app: Context, uri: Uri): String {
        var name = ""
        app.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0) name = c.getString(ni) ?: ""
            }
        }
        if (name.isNotEmpty() && !name.lowercase().endsWith(".zip")) {
            return "Ce fichier n'est pas un .zip. Choisissez « vosk-model-small-fr-0.22.zip »."
        }
        val base = File(app.filesDir, "vosk")
        val tmp = File(base, "import")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val tmpPath = tmp.canonicalPath + File.separator
        var count = 0
        val input = app.contentResolver.openInputStream(uri) ?: return "Impossible d'ouvrir le fichier choisi."
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val out = File(tmp, entry.name)
                // Sécurité : refuse tout chemin qui sortirait du dossier prévu.
                if (!out.canonicalPath.startsWith(tmpPath)) continue
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                    count++
                    if (count % 10 == 0) main.post { WakeStatus.line = "Importation… $count fichiers" }
                }
            }
        }
        val root = (listOf(tmp) + (tmp.listFiles()?.filter { it.isDirectory } ?: emptyList()))
            .firstOrNull { looksLikeModel(it) }
        if (root == null) {
            tmp.deleteRecursively()
            return "Ce .zip ne contient pas de modèle Vosk. Téléchargez « vosk-model-small-fr-0.22.zip »."
        }
        val target = dir(app)
        target.deleteRecursively()
        target.parentFile?.mkdirs()
        if (!root.renameTo(target)) {
            root.copyRecursively(target, overwrite = true)
        }
        tmp.deleteRecursively()
        return "✅ Modèle de mot d'activation installé."
    }
}
