package com.sahelvoice.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Le « cerveau » de la version 0.1 : comprend, exécute, répond. */
class Assistant(context: Context) {

    private val store = HistoryStore(context)
    private val phone = PhoneActions(context)
    private var nextId = System.currentTimeMillis()

    val messages = mutableStateListOf<Msg>().apply { addAll(store.load()) }
    // Version 0.2 : français uniquement.
    var uiLang by mutableStateOf(Lang.FR)
        private set
    var ttsEnabled by mutableStateOf(store.ttsEnabled)
        private set
    var listening by mutableStateOf(false)
        private set
    var partial by mutableStateOf("")
        private set
    var recMode by mutableStateOf(RecMode.NONE)
        private set

    /** Change quand l'état de l'IA change, pour rafraîchir l'écran. */
    var aiTick by mutableIntStateOf(0)
        private set

    /** L'IA locale (discussion libre). */
    val chat = ChatEngine.get(context) { aiTick++ }

    /** Change quand l'état des voix change, pour rafraîchir l'écran. */
    var voiceTick by mutableIntStateOf(0)
        private set

    private val appContext = context
    private val speaker = Speaker(
        context,
        onReady = { voiceTick++ },
        onSpeakError = { l ->
            voiceTick++
            add(Msg(nextId++, Kind.ERROR, Replies.voiceFailed[l], l))
        },
    )

    private val voice = VoiceInput(
        context,
        onListening = { listening = it; if (!it) partial = "" },
        onPartial = { partial = it },
        onResult = { text -> submit(text) },
        onFailure = { code -> addReply(Outcome(Kind.ERROR, Replies.recError(code)), uiLang, speak = false) },
    )

    init {
        store.uiLang = Lang.FR
        recMode = voice.bestMode(uiLang)
        store.takeLastCrash()?.let { trace ->
            add(
                Msg(
                    nextId++, Kind.ERROR,
                    "L'application s'est arrêtée la dernière fois. Envoyez une capture de ce message :\n" +
                        trace.lines().take(14).joinToString("\n"),
                    Lang.FR,
                ),
            )
        }
    }

    /** Ouvre l'installation des voix (ou les réglages de synthèse vocale). */
    fun openVoiceSettings() {
        val intents = listOf(
            android.content.Intent(android.speech.tts.TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
            android.content.Intent("com.android.settings.TTS_SETTINGS"),
            android.content.Intent(android.provider.Settings.ACTION_SETTINGS),
        )
        for (i in intents) {
            try {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                appContext.startActivity(i)
                return
            } catch (_: Throwable) {
            }
        }
    }

    fun voiceState(): VoiceState = speaker.state(uiLang)

    fun setLang(l: Lang) {
        uiLang = l
        store.uiLang = l
        recMode = voice.bestMode(l)
    }

    fun toggleTts() {
        ttsEnabled = !ttsEnabled
        store.ttsEnabled = ttsEnabled
        if (!ttsEnabled) speaker.stop()
    }

    fun startListening() {
        speaker.stop()
        recMode = voice.start(uiLang)
        if (recMode == RecMode.NONE) addReply(Outcome(Kind.ERROR, Ui.recNone), uiLang, speak = false)
    }

    fun stopListening() = voice.cancel()

    /** Arrête la réponse de l'IA en cours et la voix. */
    fun stopAll() {
        chat.stop()
        speaker.stop()
    }

    fun importModel(uri: android.net.Uri) = chat.import(uri)
    fun deleteModel() = chat.delete()

    /** true si Sahel Voice est déjà l'application d'assistance du téléphone. */
    fun isDefaultAssistant(): Boolean = try {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val rm = appContext.getSystemService(android.app.role.RoleManager::class.java)
            rm != null && rm.isRoleAvailable(android.app.role.RoleManager.ROLE_ASSISTANT) &&
                rm.isRoleHeld(android.app.role.RoleManager.ROLE_ASSISTANT)
        } else {
            false
        }
    } catch (_: Throwable) {
        false
    }

    /** Ouvre l'écran Android où l'on choisit l'application d'assistance. */
    fun openAssistantSettings() {
        val intents = listOf(
            android.content.Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS),
            android.content.Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS"),
            android.content.Intent(android.provider.Settings.ACTION_SETTINGS),
        )
        for (i in intents) {
            try {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                appContext.startActivity(i)
                return
            } catch (_: Throwable) {
            }
        }
    }

    private fun openFirst(vararg intents: android.content.Intent) {
        for (i in intents) {
            try {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                appContext.startActivity(i)
                return
            } catch (_: Throwable) {
            }
        }
    }

    private val pkgUri get() = android.net.Uri.parse("package:" + appContext.packageName)

    /** Réglage « Afficher par-dessus les autres applications ». */
    fun openOverlaySettings() = openFirst(
        android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri),
        android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri),
    )

    /** Page « Infos sur l'appli » (batterie, démarrage automatique, autorisations). */
    fun openAppSettings() = openFirst(
        android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri),
        android.content.Intent(android.provider.Settings.ACTION_SETTINGS),
    )

    fun canOpenScreensInBackground(): Boolean = android.provider.Settings.canDrawOverlays(appContext)

    /** Ouvre une page de téléchargement dans le navigateur (Chrome). */
    fun openUrl(url: String) {
        try {
            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(i)
        } catch (_: Throwable) {
        }
    }

    fun micDenied() = addReply(Outcome(Kind.ERROR, Ui.micDenied), uiLang, speak = false)

    fun clearHistory() {
        speaker.stop()
        chat.clearHistory()
        messages.clear()
        store.save(messages)
    }

    /** Traite une commande dite ou écrite, sans jamais faire planter l'application. */
    fun submit(raw: String) {
        try {
            submitUnsafe(raw)
        } catch (e: Throwable) {
            add(Msg(nextId++, Kind.ERROR, "Erreur interne : " + e.toString().take(300), Lang.FR))
        }
    }

    private fun submitUnsafe(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val parsed = CommandEngine.parse(text, uiLang)
        val lang = Lang.FR
        add(Msg(nextId++, Kind.USER, text, lang))

        // Une vraie question (longue, ou commençant par « explique », « raconte »…) va à l'IA,
        // même si elle contient par hasard un mot de commande comme « lampe » ou « date ».
        val keepCommand = parsed.cmd is Cmd.StopSpeaking || parsed.cmd is Cmd.Repeat || parsed.cmd is Cmd.ClearHistory
        if (chat.state == AiState.READY && !keepCommand && looksLikeChat(text)) {
            askAi(text)
            return
        }

        when (val c = parsed.cmd) {
            Cmd.StopSpeaking -> {
                chat.stop()
                speaker.stop()
                addReply(Outcome(Kind.ACTION, Replies.stopped), lang, speak = false)
            }
            Cmd.Repeat -> {
                val last = messages.lastOrNull { it.kind != Kind.USER }
                if (last == null) addReply(Outcome(Kind.INFO, Replies.nothingToRepeat), lang)
                else if (ttsEnabled) speaker.speak(last.text, last.lang)
            }
            Cmd.ClearHistory -> {
                clearHistory()
                addReply(Outcome(Kind.ACTION, Replies.cleared), lang)
            }
            Cmd.TorchOn -> addReply(phone.torch(true), lang)
            Cmd.TorchOff -> addReply(phone.torch(false), lang)
            Cmd.VolumeUp -> addReply(phone.volume(true), lang)
            Cmd.VolumeDown -> addReply(phone.volume(false), lang)
            Cmd.Battery -> addReply(phone.battery(), lang)
            Cmd.Time -> addReply(Outcome(Kind.INFO, Replies.time(hhmm(nowHour(), nowMinute()))), lang)
            Cmd.Date -> addReply(Outcome(Kind.INFO, dateReply()), lang)
            Cmd.Camera -> addReply(phone.camera(), lang)
            Cmd.Settings -> addReply(phone.settings(), lang)
            Cmd.Help -> addReply(Outcome(Kind.INFO, Replies.help), lang)
            Cmd.Greeting -> addReply(Outcome(Kind.INFO, Replies.greeting), lang)
            Cmd.Thanks -> addReply(Outcome(Kind.INFO, Replies.thanks), lang)
            is Cmd.Alarm -> {
                val h = c.hour
                if (h == null) addReply(Outcome(Kind.INFO, Replies.alarmNoTime), lang)
                else addReply(phone.alarm(h, c.minute, hhmm(h, c.minute)), lang)
            }
            is Cmd.Dial -> addReply(phone.dial(c.number), lang)
            is Cmd.OpenApp -> addReply(phone.openApp(c.name), lang)
            Cmd.Unknown -> when (chat.state) {
                AiState.READY -> askAi(text)
                AiState.LOADING -> add(Msg(nextId++, Kind.INFO, AI_LOADING, lang))
                AiState.IMPORTING -> add(Msg(nextId++, Kind.INFO, AI_IMPORTING, lang))
                else -> addReply(Outcome(Kind.INFO, T(AI_MISSING, AI_MISSING, AI_MISSING)), lang)
            }
        }
    }

    private val chatStarts = listOf(
        "explique", "expliquer", "raconte", "racontes", "pourquoi", "comment", "qu est ce", "c est quoi",
        "qui est", "qui etait", "traduis", "traduire", "resume", "resumer", "aide moi a", "donne moi",
        "ecris", "propose", "conseille", "peux tu m expliquer", "dis moi", "parle moi", "que penses tu",
        "quelle est la difference", "definis", "qu est ce que",
    ).map { normalizeText(it) }

    private fun looksLikeChat(raw: String): Boolean {
        val t = normalizeText(raw)
        val words = t.split(" ").count { it.isNotBlank() }
        if (words > 10) return true
        return chatStarts.any { t == it || t.startsWith("$it ") }
    }

    /** Envoie la question à l'IA et affiche la réponse au fur et à mesure. */
    private fun askAi(question: String) {
        if (chat.generating) {
            add(Msg(nextId++, Kind.INFO, "Je réponds encore à la question précédente. Touchez ⏹ pour l'arrêter.", Lang.FR))
            return
        }
        if (chat.memoryLooksLow()) {
            add(Msg(nextId++, Kind.INFO, "Attention : la mémoire libre du téléphone est faible. Si l'application se ferme, fermez d'autres applications.", Lang.FR))
        }
        speaker.stop()
        val id = nextId++
        messages.add(Msg(id, Kind.AI, "…", Lang.FR))
        chat.ask(
            question,
            onPartial = { partialText -> replaceText(id, if (partialText.isBlank()) "…" else partialText) },
            onDone = { answer, error ->
                if (answer != null) {
                    replaceText(id, answer)
                    store.save(messages)
                    if (ttsEnabled) speaker.speak(answer, Lang.FR)
                } else {
                    val i = messages.indexOfLast { it.id == id }
                    if (i >= 0) messages[i] = messages[i].copy(kind = Kind.ERROR, text = error ?: "Erreur de l'IA.")
                    store.save(messages)
                }
            },
        )
    }

    private fun replaceText(id: Long, text: String) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }

    private fun addReply(o: Outcome, lang: Lang, speak: Boolean = true) {
        val text = o.text[lang]
        add(Msg(nextId++, o.kind, text, lang))
        if (speak && ttsEnabled) speaker.speak(text, lang)
    }

    private fun add(m: Msg) {
        messages.add(m)
        while (messages.size > HistoryStore.MAX) messages.removeAt(0)
        store.save(messages)
    }

    fun shutdown() {
        chat.stop()
        voice.cancel()
        speaker.shutdown()
    }

    companion object {
        const val AI_MISSING =
            "Je n'ai pas compris cette commande. Pour discuter librement, installez d'abord l'IA : touchez 🧠 en haut de l'écran."
        const val AI_LOADING = "L'IA est en train de se charger, réessayez dans quelques secondes."
        const val AI_IMPORTING = "L'IA est en cours d'importation, patientez jusqu'à 100 %."
    }

    // --- Date et heure ---

    private fun nowHour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    private fun nowMinute() = Calendar.getInstance().get(Calendar.MINUTE)
    private fun hhmm(h: Int, m: Int) = String.format(Locale.ROOT, "%02d:%02d", h, m)

    private fun dateReply(): T {
        val now = Date()
        val fr = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(now)
        val ar = SimpleDateFormat("EEEE d MMMM yyyy", Locale.forLanguageTag("ar")).format(now)
        val cal = Calendar.getInstance()
        val days = listOf("Lahadi", "Litinin", "Talata", "Laraba", "Alhamis", "Juma'a", "Asabar")
        val months = listOf(
            "Janairu", "Faburairu", "Maris", "Afirilu", "Mayu", "Yuni",
            "Yuli", "Agusta", "Satumba", "Oktoba", "Nuwamba", "Disamba",
        )
        val ha = "${days[cal.get(Calendar.DAY_OF_WEEK) - 1]}, ${cal.get(Calendar.DAY_OF_MONTH)} ga " +
            "${months[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
        return Replies.date(fr, ar, ha)
    }
}
