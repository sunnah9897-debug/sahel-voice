package com.sahelvoice.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Le « cerveau » de la version 0.1 : comprend, exécute, répond. */
class Assistant(context: Context) {

    private val store = HistoryStore(context)
    private val phone = PhoneActions(context)
    private var nextId = System.currentTimeMillis()

    val messages = mutableStateListOf<Msg>().apply { addAll(store.load()) }
    var uiLang by mutableStateOf(store.uiLang)
        private set
    var ttsEnabled by mutableStateOf(store.ttsEnabled)
        private set
    var listening by mutableStateOf(false)
        private set
    var partial by mutableStateOf("")
        private set
    var recMode by mutableStateOf(RecMode.NONE)
        private set

    /** Change quand l'état des voix change, pour rafraîchir l'écran. */
    var voiceTick by mutableIntStateOf(0)
        private set

    private val speaker = Speaker(context) { voiceTick++ }

    private val voice = VoiceInput(
        context,
        onListening = { listening = it; if (!it) partial = "" },
        onPartial = { partial = it },
        onResult = { text -> submit(text) },
        onError = { code -> addReply(Outcome(Kind.ERROR, Replies.recError(code)), uiLang, speak = false) },
    )

    init {
        recMode = voice.bestMode(uiLang)
    }

    fun voiceState(): VoiceState = speaker.state(uiLang)

    fun setLang(l: Lang) {
        uiLang = l
        store.uiLang = l
        recMode = voice.bestMode(l)
    }

    fun toggleTts() {
        ttsEnabled = !ttsEnabled
        store.ttsEnabled = ttsEnabled
        if (!ttsEnabled) speaker.stop()
    }

    fun startListening() {
        speaker.stop()
        recMode = voice.start(uiLang)
        if (recMode == RecMode.NONE) addReply(Outcome(Kind.ERROR, Ui.recNone), uiLang, speak = false)
    }

    fun stopListening() = voice.cancel()

    fun micDenied() = addReply(Outcome(Kind.ERROR, Ui.micDenied), uiLang, speak = false)

    fun clearHistory() {
        speaker.stop()
        messages.clear()
        store.save(messages)
    }

    /** Traite une commande dite ou écrite. */
    fun submit(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val parsed = CommandEngine.parse(text, uiLang)
        val lang = parsed.lang ?: uiLang
        add(Msg(nextId++, Kind.USER, text, lang))

        when (val c = parsed.cmd) {
            Cmd.StopSpeaking -> {
                speaker.stop()
                addReply(Outcome(Kind.ACTION, Replies.stopped), lang, speak = false)
            }
            Cmd.Repeat -> {
                val last = messages.lastOrNull { it.kind != Kind.USER }
                if (last == null) addReply(Outcome(Kind.INFO, Replies.nothingToRepeat), lang)
                else if (ttsEnabled) speaker.speak(last.text, last.lang)
            }
            Cmd.ClearHistory -> {
                clearHistory()
                addReply(Outcome(Kind.ACTION, Replies.cleared), lang)
            }
            Cmd.TorchOn -> addReply(phone.torch(true), lang)
            Cmd.TorchOff -> addReply(phone.torch(false), lang)
            Cmd.VolumeUp -> addReply(phone.volume(true), lang)
            Cmd.VolumeDown -> addReply(phone.volume(false), lang)
            Cmd.Battery -> addReply(phone.battery(), lang)
            Cmd.Time -> addReply(Outcome(Kind.INFO, Replies.time(hhmm(nowHour(), nowMinute()))), lang)
            Cmd.Date -> addReply(Outcome(Kind.INFO, dateReply()), lang)
            Cmd.Camera -> addReply(phone.camera(), lang)
            Cmd.Settings -> addReply(phone.settings(), lang)
            Cmd.Help -> addReply(Outcome(Kind.INFO, Replies.help), lang)
            Cmd.Greeting -> addReply(Outcome(Kind.INFO, Replies.greeting), lang)
            Cmd.Thanks -> addReply(Outcome(Kind.INFO, Replies.thanks), lang)
            is Cmd.Alarm -> {
                val h = c.hour
                if (h == null) addReply(Outcome(Kind.INFO, Replies.alarmNoTime), lang)
                else addReply(phone.alarm(h, c.minute, hhmm(h, c.minute)), lang)
            }
            is Cmd.Dial -> addReply(phone.dial(c.number), lang)
            is Cmd.OpenApp -> addReply(phone.openApp(c.name), lang)
            Cmd.Unknown -> addReply(Outcome(Kind.INFO, Replies.unknown), lang)
        }
    }

    private fun addReply(o: Outcome, lang: Lang, speak: Boolean = true) {
        val text = o.text[lang]
        add(Msg(nextId++, o.kind, text, lang))
        if (speak && ttsEnabled) speaker.speak(text, lang)
    }

    private fun add(m: Msg) {
        messages.add(m)
        while (messages.size > HistoryStore.MAX) messages.removeAt(0)
        store.save(messages)
    }

    fun shutdown() {
        voice.cancel()
        speaker.shutdown()
    }

    // --- Date et heure ---

    private fun nowHour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    private fun nowMinute() = Calendar.getInstance().get(Calendar.MINUTE)
    private fun hhmm(h: Int, m: Int) = String.format(Locale.ROOT, "%02d:%02d", h, m)

    private fun dateReply(): T {
        val now = Date()
        val fr = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(now)
        val ar = SimpleDateFormat("EEEE d MMMM yyyy", Locale.forLanguageTag("ar")).format(now)
        val cal = Calendar.getInstance()
        val days = listOf("Lahadi", "Litinin", "Talata", "Laraba", "Alhamis", "Juma'a", "Asabar")
        val months = listOf(
            "Janairu", "Faburairu", "Maris", "Afirilu", "Mayu", "Yuni",
            "Yuli", "Agusta", "Satumba", "Oktoba", "Nuwamba", "Disamba",
        )
        val ha = "${days[cal.get(Calendar.DAY_OF_WEEK) - 1]}, ${cal.get(Calendar.DAY_OF_MONTH)} ga " +
            "${months[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
        return Replies.date(fr, ar, ha)
    }
}
