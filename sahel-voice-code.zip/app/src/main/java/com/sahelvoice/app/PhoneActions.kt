package com.sahelvoice.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

/** Résultat d'une action : texte de réponse et type. */
data class Outcome(val kind: Kind, val text: T)

/** Actions sur le téléphone, uniquement avec les API officielles d'Android. */
class PhoneActions(private val context: Context) {

    fun torch(on: Boolean): Outcome {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cid ->
                cm.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Outcome(Kind.ERROR, Replies.torchNone)
            cm.setTorchMode(id, on)
            Outcome(Kind.ACTION, if (on) Replies.torchOn else Replies.torchOff)
        } catch (e: Exception) {
            Outcome(Kind.ERROR, Replies.torchBusy)
        }
    }

    fun volume(up: Boolean): Outcome {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        return try {
            // Deux crans pour que le changement soit bien audible.
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            Outcome(Kind.ACTION, Replies.volume(up, cur * 100 / max))
        } catch (e: Exception) {
            Outcome(Kind.ERROR, Replies.cantOpen)
        }
    }

    fun battery(): Outcome {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return Outcome(Kind.INFO, Replies.battery(pct, charging))
    }

    fun alarm(hour: Int, minute: Int, hhmm: String): Outcome {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Sahel Voice")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return if (launch(intent)) Outcome(Kind.ACTION, Replies.alarmSet(hhmm))
        else Outcome(Kind.ERROR, Replies.alarmFail)
    }

    fun camera(): Outcome =
        if (launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) Outcome(Kind.ACTION, Replies.camera)
        else Outcome(Kind.ERROR, Replies.cantOpen)

    fun settings(): Outcome =
        if (launch(Intent(Settings.ACTION_SETTINGS))) Outcome(Kind.ACTION, Replies.settings)
        else Outcome(Kind.ERROR, Replies.cantOpen)

    /** Prépare un appel : l'utilisateur doit lui-même appuyer sur « Appeler ». */
    fun dial(number: String?): Outcome {
        val uri = Uri.parse("tel:" + (number ?: ""))
        return if (launch(Intent(Intent.ACTION_DIAL, uri))) Outcome(Kind.ACTION, Replies.dial(number))
        else Outcome(Kind.ERROR, Replies.cantOpen)
    }

    /** Ouvre une application installée à partir de son nom dit à voix haute. */
    fun openApp(spokenName: String): Outcome {
        val name = spokenName.trim()
        if (name.isEmpty()) return Outcome(Kind.INFO, Replies.askAppName)
        val norm = normalizeText(name)
        val pm = context.packageManager

        // 1. Application connue (WhatsApp, YouTube…) : par son paquet.
        val canonical = AppAliases.find(norm)
        if (canonical != null) {
            for (pkg in AppAliases.packagesFor(canonical)) {
                val i = pm.getLaunchIntentForPackage(pkg)
                if (i != null && launch(i)) return Outcome(Kind.ACTION, Replies.opening(canonical))
            }
        }

        // 2. Recherche par le nom affiché sous l'icône.
        val wanted = (listOf(norm) + (canonical?.let { AppAliases.labelsFor(it) } ?: emptyList()))
            .map { it.replace(" ", "") }
            .filter { it.length >= 2 }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(launcher, 0)
        var best: Pair<Int, Pair<String, String>>? = null // (score, (paquet, nom))
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val l = normalizeText(label).replace(" ", "")
            if (l.isEmpty()) continue
            for (w in wanted) {
                val score = when {
                    l == w -> 3
                    l.startsWith(w) || w.startsWith(l) -> 2
                    l.contains(w) || (l.length >= 4 && w.contains(l)) -> 1
                    else -> 0
                }
                if (score > (best?.first ?: 0)) best = score to (ri.activityInfo.packageName to label)
            }
        }
        val found = best?.second
        if (found != null) {
            val i = pm.getLaunchIntentForPackage(found.first)
            if (i != null && launch(i)) return Outcome(Kind.ACTION, Replies.opening(found.second))
        }
        return Outcome(Kind.ERROR, Replies.appMissing(canonical ?: name))
    }

    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
