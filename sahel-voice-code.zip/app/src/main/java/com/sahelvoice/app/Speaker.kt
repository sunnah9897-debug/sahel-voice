package com.sahelvoice.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice

/** État de la voix pour une langue. */
enum class VoiceState { LOADING, OFFLINE, ONLINE_ONLY, MISSING_DATA, NONE }

/**
 * Synthèse vocale (texte -> voix) avec le moteur Android installé (souvent Google).
 * On choisit en priorité une voix qui fonctionne sans Internet.
 * Toutes les opérations sont protégées : une voix absente ne doit jamais faire planter l'application.
 */
class Speaker(
    context: Context,
    private val onReady: () -> Unit,
    /** Appelé (sur le fil principal) quand une phrase n'a pas pu être lue. */
    private val onSpeakError: (Lang) -> Unit,
) : TextToSpeech.OnInitListener {

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val tts: TextToSpeech? = try {
        TextToSpeech(context.applicationContext, this)
    } catch (e: Throwable) {
        null
    }
    private var ready = false
    private var failed = tts == null
    private val pending = mutableMapOf<String, Lang>()

    /** Appelé (sur le fil principal) quand la voix a fini de parler (ou a échoué). */
    @Volatile var onIdle: (() -> Unit)? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS && tts != null
        failed = !ready
        if (ready) {
            try {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId != null) synchronized(pending) { pending.remove(utteranceId) }
                        main.post { onIdle?.invoke() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = fail(utteranceId)
                    override fun onError(utteranceId: String?, errorCode: Int) = fail(utteranceId)
                })
            } catch (_: Throwable) {
            }
        }
        main.post { onReady() }
    }

    private fun fail(id: String?) {
        main.post { onIdle?.invoke() }
        if (id == null) return
        val lang = synchronized(pending) { pending.remove(id) } ?: return
        main.post { onSpeakError(lang) }
    }

    private fun voicesFor(lang: Lang): List<Voice> = try {
        tts?.voices.orEmpty().filter { v ->
            v.locale?.language == lang.locale.language &&
                !(v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) ?: false)
        }
    } catch (e: Throwable) {
        emptyList()
    }

    private fun offlineVoice(lang: Lang): Voice? =
        voicesFor(lang).filter { !it.isNetworkConnectionRequired }.maxByOrNull { it.quality }

    /** Résultat de isLanguageAvailable, ou -2 (non pris en charge) en cas d'erreur. */
    private fun availability(lang: Lang): Int = try {
        tts?.isLanguageAvailable(lang.locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
    } catch (e: Throwable) {
        TextToSpeech.LANG_NOT_SUPPORTED
    }

    fun state(lang: Lang): VoiceState {
        if (failed) return VoiceState.NONE
        if (!ready) return VoiceState.LOADING
        val a = availability(lang)
        if (a == TextToSpeech.LANG_MISSING_DATA) return VoiceState.MISSING_DATA
        if (a == TextToSpeech.LANG_NOT_SUPPORTED) return VoiceState.NONE
        if (offlineVoice(lang) != null) return VoiceState.OFFLINE
        return VoiceState.ONLINE_ONLY
    }

    /** Parle. Renvoie false si la phrase ne peut pas être lue dans cette langue. */
    fun speak(text: String, lang: Lang): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        return try {
            val st = state(lang)
            if (st == VoiceState.NONE || st == VoiceState.MISSING_DATA) return false
            val r = engine.setLanguage(lang.locale)
            if (r < 0) return false
            offlineVoice(lang)?.let { v -> try { engine.voice = v } catch (_: Throwable) {} }
            val id = "sv-" + System.nanoTime()
            synchronized(pending) { pending[id] = lang }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS
        } catch (e: Throwable) {
            false
        }
    }

    fun stop() {
        try {
            if (ready) tts?.stop()
        } catch (_: Throwable) {
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Throwable) {
        }
    }
}
