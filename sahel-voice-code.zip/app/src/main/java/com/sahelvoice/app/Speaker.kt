package com.sahelvoice.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice

/** État de la voix pour une langue. */
enum class VoiceState { LOADING, OFFLINE, ONLINE_ONLY, NONE }

/**
 * Synthèse vocale (texte -> voix) avec le moteur Android installé (souvent Google).
 * On choisit en priorité une voix qui fonctionne sans Internet.
 */
class Speaker(context: Context, private val onReady: () -> Unit) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var failed = false

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        failed = !ready
        onReady()
    }

    private fun voicesFor(lang: Lang): List<Voice> = try {
        tts.voices.orEmpty().filter { v ->
            v.locale.language == lang.locale.language &&
                !(v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) ?: false)
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun offlineVoice(lang: Lang): Voice? =
        voicesFor(lang).filter { !it.isNetworkConnectionRequired }.maxByOrNull { it.quality }

    fun state(lang: Lang): VoiceState {
        if (failed) return VoiceState.NONE
        if (!ready) return VoiceState.LOADING
        if (offlineVoice(lang) != null) return VoiceState.OFFLINE
        if (voicesFor(lang).isNotEmpty()) return VoiceState.ONLINE_ONLY
        return VoiceState.NONE
    }

    /** Parle. Renvoie false si aucune voix n'est disponible pour cette langue. */
    fun speak(text: String, lang: Lang): Boolean {
        if (!ready) return false
        val voice = offlineVoice(lang) ?: voicesFor(lang).maxByOrNull { it.quality } ?: return false
        return try {
            tts.voice = voice
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sv-" + System.nanoTime()) == TextToSpeech.SUCCESS
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        if (ready) tts.stop()
    }

    fun shutdown() {
        try {
            tts.stop()
            tts.shutdown()
        } catch (_: Exception) {
        }
    }
}
