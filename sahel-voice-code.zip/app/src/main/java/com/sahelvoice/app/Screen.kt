package com.sahelvoice.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen(a: Assistant, onMic: () -> Unit) {
    val lang = a.uiLang
    var input by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }

    val send = {
        val txt = input
        input = ""
        a.submit(txt)
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides if (lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = { Header(a, onClear = { confirmClear = true }) },
            bottomBar = {
                InputBar(
                    a = a,
                    input = input,
                    onInput = { input = it },
                    onSend = send,
                    onMic = onMic,
                )
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                val list = a.messages.toList().asReversed()
                if (list.isEmpty()) {
                    Text(
                        Ui.emptyHint[lang],
                        modifier = Modifier.align(Alignment.Center).padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                } else {
                    LazyColumn(
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    ) {
                        items(list) { m -> Bubble(m, lang) }
                    }
                }
            }
        }

        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false },
                title = { Text(Ui.clearTitle[lang]) },
                text = { Text(Ui.clearText[lang]) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmClear = false
                        a.clearHistory()
                    }) { Text(Ui.clearYes[lang]) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmClear = false }) { Text(Ui.cancel[lang]) }
                },
            )
        }
    }
}

@Composable
private fun Header(a: Assistant, onClear: () -> Unit) {
    val lang = a.uiLang
    val headerColor = if (isSystemInDarkTheme()) Color(0xFF173F36) else Color(0xFF1F6F5C)
    Surface(color = headerColor, contentColor = Color.White) {
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Ui.appName[lang],
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                EmojiButton(if (a.ttsEnabled) "🔊" else "🔇") { a.toggleTts() }
                EmojiButton("🗑") { onClear() }
            }
            Text(Ui.local[lang], style = MaterialTheme.typography.labelMedium, color = Color(0xFFF0D9A8))
            Spacer(Modifier.size(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Lang.entries.forEach { l ->
                    val selected = l == lang
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (selected) Color(0xFFF0B060) else Color.Transparent,
                        contentColor = if (selected) Color(0xFF3A2400) else Color.White,
                        border = if (selected) null else BorderStroke(1.dp, Color(0x99FFFFFF)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { a.setLang(l) },
                    ) {
                        Text(
                            l.short,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelLarge,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmojiButton(emoji: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = 22.sp)
    }
}

@Composable
private fun Bubble(m: Msg, ui: Lang) {
    val isUser = m.kind == Kind.USER
    val cs = MaterialTheme.colorScheme
    val bg = when (m.kind) {
        Kind.USER -> cs.primaryContainer
        Kind.ERROR -> cs.errorContainer
        else -> cs.surfaceVariant
    }
    val fg = when (m.kind) {
        Kind.USER -> cs.onPrimaryContainer
        Kind.ERROR -> cs.onErrorContainer
        else -> cs.onSurfaceVariant
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = bg,
            contentColor = fg,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (!isUser) {
                    val badge = when (m.kind) {
                        Kind.ACTION -> Ui.badgeAction[ui]
                        Kind.ERROR -> Ui.badgeError[ui]
                        else -> Ui.badgeInfo[ui]
                    }
                    Text(
                        badge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (m.kind == Kind.ACTION) cs.primary else fg,
                    )
                    Spacer(Modifier.size(2.dp))
                }
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (m.lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
                ) {
                    Text(m.text, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

@Composable
private fun InputBar(
    a: Assistant,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
) {
    val lang = a.uiLang
    val cs = MaterialTheme.colorScheme
    @Suppress("UNUSED_VARIABLE")
    val tick = a.voiceTick // relit l'état des voix quand le moteur est prêt
    val voiceLine = if (!a.ttsEnabled) Ui.voiceOff[lang] else when (a.voiceState()) {
        VoiceState.LOADING -> Ui.voiceLoading[lang]
        VoiceState.OFFLINE -> Ui.voiceOffline[lang]
        VoiceState.ONLINE_ONLY -> Ui.voiceOnline[lang]
        VoiceState.MISSING_DATA -> Ui.voiceMissing[lang]
        VoiceState.NONE -> Ui.voiceNone[lang]
    }
    val canInstall = a.ttsEnabled && lang != Lang.HA &&
        a.voiceState().let { it == VoiceState.MISSING_DATA || it == VoiceState.ONLINE_ONLY || it == VoiceState.NONE }
    val recLine = when (a.recMode) {
        RecMode.ON_DEVICE -> Ui.recOnDevice[lang]
        RecMode.STANDARD -> Ui.recStandard[lang]
        RecMode.NONE -> Ui.recNone[lang]
    }

    Surface(color = cs.surface, tonalElevation = 3.dp, shadowElevation = 6.dp) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(12.dp),
        ) {
            if (a.listening) {
                Text(
                    if (a.partial.isBlank()) Ui.listening[lang] else "« ${a.partial} »",
                    color = cs.secondary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge,
                )
                Spacer(Modifier.size(6.dp))
            }
            Text(voiceLine, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            if (canInstall) {
                Text(
                    Ui.installVoice[lang],
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.primary,
                    modifier = Modifier.clickable { a.openVoiceSettings() }.padding(vertical = 4.dp),
                )
            }
            Text(recLine, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(Ui.typeHere[lang]) },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                )
                Spacer(Modifier.width(10.dp))
                if (input.isNotBlank()) {
                    RoundButton("➤", cs.primary, cs.onPrimary, onSend)
                } else {
                    RoundButton(
                        "🎤",
                        if (a.listening) Color(0xFFC0392B) else cs.primary,
                        Color.White,
                        onMic,
                    )
                }
            }
        }
    }
}

@Composable
private fun RoundButton(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = bg,
        contentColor = fg,
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, fontSize = 26.sp)
        }
    }
}
