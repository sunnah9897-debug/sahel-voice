package com.sahelvoice.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen(a: Assistant, onMic: () -> Unit, onPickModel: () -> Unit) {
    val lang = a.uiLang
    var input by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    var showQuick by remember { mutableStateOf(false) }

    val send = {
        val txt = input
        input = ""
        a.submit(txt)
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides if (lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Header(a, onClear = { confirmClear = true }, onAi = { showAi = true }, onQuick = { showQuick = true })
            },
            bottomBar = {
                InputBar(
                    a = a,
                    input = input,
                    onInput = { input = it },
                    onSend = send,
                    onMic = onMic,
                )
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                val list = a.messages.toList().asReversed()
                if (list.isEmpty()) {
                    Text(
                        Ui.emptyHint[lang],
                        modifier = Modifier.align(Alignment.Center).padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                } else {
                    LazyColumn(
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    ) {
                        items(list) { m -> Bubble(m, lang) }
                    }
                }
            }
        }

        if (showQuick) {
            QuickAccessDialog(a, onDismiss = { showQuick = false })
        }

        if (showAi) {
            AiDialog(a, onDismiss = { showAi = false }, onPickModel = {
                showAi = false
                onPickModel()
            })
        }

        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false },
                title = { Text(Ui.clearTitle[lang]) },
                text = { Text(Ui.clearText[lang]) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmClear = false
                        a.clearHistory()
                    }) { Text(Ui.clearYes[lang]) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmClear = false }) { Text(Ui.cancel[lang]) }
                },
            )
        }
    }
}

@Composable
private fun Header(a: Assistant, onClear: () -> Unit, onAi: () -> Unit, onQuick: () -> Unit) {
    val lang = a.uiLang
    val headerColor = if (isSystemInDarkTheme()) Color(0xFF173F36) else Color(0xFF1F6F5C)
    Surface(color = headerColor, contentColor = Color.White) {
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Ui.appName[lang],
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                EmojiButton("⚡") { onQuick() }
                EmojiButton("🧠") { onAi() }
                EmojiButton(if (a.ttsEnabled) "🔊" else "🔇") { a.toggleTts() }
                EmojiButton("🗑") { onClear() }
            }
            Text(Ui.local[lang], style = MaterialTheme.typography.labelMedium, color = Color(0xFFF0D9A8))
            Text(
                aiStatus(a),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                modifier = Modifier.clickable { onAi() }.padding(top = 4.dp),
            )
        }
    }
}

/** Ligne d'état de l'IA, affichée sous le titre. */
private fun aiStatus(a: Assistant): String {
    @Suppress("UNUSED_VARIABLE")
    val tick = a.aiTick
    val c = a.chat
    return when (c.state) {
        AiState.ABSENT -> "🧠 IA : non installée — touchez ici pour l'installer"
        AiState.IMPORTING -> "🧠 Importation de l'IA : ${c.importPercent} %"
        AiState.LOADING -> "🧠 Chargement de l'IA…"
        AiState.READY -> if (c.generating) "🧠 L'IA réfléchit…" else "🧠 IA prête : ${c.modelName} (${c.modelSizeMb} Mo)"
        AiState.ERROR -> "🧠 IA : problème — touchez ici"
    }
}

@Composable
private fun AiDialog(a: Assistant, onDismiss: () -> Unit, onPickModel: () -> Unit) {
    @Suppress("UNUSED_VARIABLE")
    val tick = a.aiTick
    val c = a.chat
    val busy = c.state == AiState.IMPORTING || c.state == AiState.LOADING || c.generating
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🧠 Discussion libre (IA locale)") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("État : " + aiStatus(a).removePrefix("🧠 "), fontWeight = FontWeight.Bold)
                c.errorText?.let { if (c.state == AiState.ERROR) Text("⚠ $it", color = MaterialTheme.colorScheme.error) }
                Text(
                    "L'IA fonctionne sans Internet, directement dans le téléphone. " +
                        "Elle peut se tromper et ne connaît pas l'actualité.",
                )
                Text("Étape 1 — Télécharger le modèle avec Chrome (une seule fois) :", fontWeight = FontWeight.Bold)
                Button(onClick = { a.openUrl(ChatEngine.URL_RECOMMENDED) }, enabled = !busy) {
                    Text("Modèle conseillé : Qwen2.5 1.5B Q4_K_M (1,12 Go)")
                }
                OutlinedButton(onClick = { a.openUrl(ChatEngine.URL_LIGHT) }, enabled = !busy) {
                    Text("Modèle léger et rapide : Qwen2.5 0.5B (429 Mo)")
                }
                Text("Étape 2 — Quand le téléchargement est fini (100 %) :", fontWeight = FontWeight.Bold)
                Button(onClick = onPickModel, enabled = !busy) {
                    Text("Importer le fichier .gguf téléchargé")
                }
                if (c.state == AiState.READY || c.state == AiState.ERROR) {
                    OutlinedButton(onClick = { a.deleteModel() }, enabled = !busy) {
                        Text("Supprimer le modèle du téléphone")
                    }
                }
                Text(
                    "Après l'importation, vous pouvez supprimer le fichier de « Téléchargements » pour libérer de la place.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

@Composable
private fun QuickAccessDialog(a: Assistant, onDismiss: () -> Unit) {
    val already = remember { a.isDefaultAssistant() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("⚡ Parler à Sahel Voice depuis n'importe où") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (already) {
                    Text("✅ Sahel Voice est déjà votre application d'assistance.", fontWeight = FontWeight.Bold)
                }
                Text("Méthode A — Appui long (application d'assistance)", fontWeight = FontWeight.Bold)
                Text(
                    "1. Touchez le bouton ci-dessous.\n" +
                        "2. Choisissez « Application d'assistance » (ou « Assistant numérique »).\n" +
                        "3. Sélectionnez Sahel Voice.\n" +
                        "Ensuite, le geste « assistant » de votre téléphone ouvre Sahel Voice déjà en écoute.",
                )
                Button(onClick = { a.openAssistantSettings() }) {
                    Text("Ouvrir le réglage de l'assistant")
                }
                Text("Méthode B — Raccourci sur l'icône (marche partout)", fontWeight = FontWeight.Bold)
                Text(
                    "Sur l'écran d'accueil, faites un appui long sur l'icône Sahel Voice, puis touchez « Écouter ». " +
                        "Vous pouvez aussi faire glisser « Écouter » sur l'écran d'accueil pour avoir un bouton direct.",
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

@Composable
private fun EmojiButton(emoji: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = 22.sp)
    }
}

@Composable
private fun Bubble(m: Msg, ui: Lang) {
    val isUser = m.kind == Kind.USER
    val cs = MaterialTheme.colorScheme
    val bg = when (m.kind) {
        Kind.USER -> cs.primaryContainer
        Kind.ERROR -> cs.errorContainer
        else -> cs.surfaceVariant
    }
    val fg = when (m.kind) {
        Kind.USER -> cs.onPrimaryContainer
        Kind.ERROR -> cs.onErrorContainer
        else -> cs.onSurfaceVariant
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = bg,
            contentColor = fg,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (!isUser) {
                    val badge = when (m.kind) {
                        Kind.AI -> "🤖 Réponse de l'IA (peut se tromper)"
                        Kind.ACTION -> Ui.badgeAction[ui]
                        Kind.ERROR -> Ui.badgeError[ui]
                        else -> Ui.badgeInfo[ui]
                    }
                    Text(
                        badge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (m.kind == Kind.ACTION) cs.primary else fg,
                    )
                    Spacer(Modifier.size(2.dp))
                }
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (m.lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
                ) {
                    Text(m.text, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

@Composable
private fun InputBar(
    a: Assistant,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
) {
    val lang = a.uiLang
    val cs = MaterialTheme.colorScheme
    @Suppress("UNUSED_VARIABLE")
    val tick = a.voiceTick // relit l'état des voix quand le moteur est prêt
    @Suppress("UNUSED_VARIABLE")
    val tick2 = a.aiTick
    val voiceLine = if (!a.ttsEnabled) Ui.voiceOff[lang] else when (a.voiceState()) {
        VoiceState.LOADING -> Ui.voiceLoading[lang]
        VoiceState.OFFLINE -> Ui.voiceOffline[lang]
        VoiceState.ONLINE_ONLY -> Ui.voiceOnline[lang]
        VoiceState.MISSING_DATA -> Ui.voiceMissing[lang]
        VoiceState.NONE -> Ui.voiceNone[lang]
    }
    val canInstall = a.ttsEnabled && lang != Lang.HA &&
        a.voiceState().let { it == VoiceState.MISSING_DATA || it == VoiceState.ONLINE_ONLY || it == VoiceState.NONE }
    val recLine = when (a.recMode) {
        RecMode.ON_DEVICE -> Ui.recOnDevice[lang]
        RecMode.STANDARD -> Ui.recStandard[lang]
        RecMode.NONE -> Ui.recNone[lang]
    }

    Surface(color = cs.surface, tonalElevation = 3.dp, shadowElevation = 6.dp) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(12.dp),
        ) {
            if (a.listening) {
                Text(
                    if (a.partial.isBlank()) Ui.listening[lang] else "« ${a.partial} »",
                    color = cs.secondary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge,
                )
                Spacer(Modifier.size(6.dp))
            }
            Text(voiceLine, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            if (canInstall) {
                Text(
                    Ui.installVoice[lang],
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.primary,
                    modifier = Modifier.clickable { a.openVoiceSettings() }.padding(vertical = 4.dp),
                )
            }
            Text(recLine, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(Ui.typeHere[lang]) },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                )
                Spacer(Modifier.width(10.dp))
                if (input.isNotBlank()) {
                    RoundButton("➤", cs.primary, cs.onPrimary, onSend)
                } else if (a.chat.generating) {
                    RoundButton("⏹", Color(0xFFC0392B), Color.White) { a.stopAll() }
                } else {
                    RoundButton(
                        "🎤",
                        if (a.listening) Color(0xFFC0392B) else cs.primary,
                        Color.White,
                        onMic,
                    )
                }
            }
        }
    }
}

@Composable
private fun RoundButton(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = bg,
        contentColor = fg,
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, fontSize = 26.sp)
        }
    }
}
