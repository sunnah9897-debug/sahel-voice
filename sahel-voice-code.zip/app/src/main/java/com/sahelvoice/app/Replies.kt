package com.sahelvoice.app

/** Réponses de l'assistant dans les trois langues. */
object Replies {
    val torchOn = T("Lampe allumée.", "تم تشغيل المصباح.", "An kunna fitila.")
    val torchOff = T("Lampe éteinte.", "تم إطفاء المصباح.", "An kashe fitila.")
    val torchNone = T(
        "Je ne trouve pas de lampe utilisable sur ce téléphone.",
        "لا يوجد مصباح يمكن استخدامه في هذا الهاتف.",
        "Ban sami fitilar da za a iya amfani da ita a wannan wayar ba.",
    )
    val torchBusy = T(
        "Impossible d'utiliser la lampe : la caméra est peut-être ouverte dans une autre application.",
        "تعذر استخدام المصباح: ربما الكاميرا مفتوحة في تطبيق آخر.",
        "Ba a iya amfani da fitila ba: watakila kyamara a buɗe take a wata manhaja.",
    )

    fun volume(up: Boolean, pct: Int) = T(
        (if (up) "Volume augmenté" else "Volume baissé") + " : $pct %.",
        (if (up) "تم رفع الصوت" else "تم خفض الصوت") + ": $pct%.",
        (if (up) "An ƙara sauti" else "An rage sauti") + ": kashi $pct cikin ɗari.",
    )

    fun battery(pct: Int, charging: Boolean) = T(
        "Batterie : $pct %" + (if (charging) ", en charge." else "."),
        "البطارية: $pct%" + (if (charging) "، قيد الشحن." else "."),
        "Batir: kashi $pct cikin ɗari" + (if (charging) ", ana caji." else "."),
    )

    fun date(fr: String, ar: String, ha: String) = T("Nous sommes le $fr.", "اليوم هو $ar.", "Yau $ha ne.")
    fun time(hhmm: String) = T("Il est $hhmm.", "الساعة الآن $hhmm.", "Yanzu ƙarfe $hhmm ne.")

    fun alarmSet(hhmm: String) = T(
        "Alarme de $hhmm envoyée à l'application Horloge.",
        "تم إرسال منبه الساعة $hhmm إلى تطبيق الساعة.",
        "An aika ƙararrawar ƙarfe $hhmm zuwa manhajar agogo.",
    )
    val alarmNoTime = T(
        "À quelle heure ? Dites par exemple : « Crée une alarme à six heures ».",
        "في أي ساعة؟ قل مثلاً: «أنشئ منبهاً الساعة السادسة».",
        "Da ƙarfe nawa? Ka ce misali: «Saita ƙararrawa da ƙarfe shida».",
    )
    val alarmFail = T(
        "L'application Horloge n'a pas accepté l'alarme.",
        "لم يقبل تطبيق الساعة المنبه.",
        "Manhajar agogo ba ta karɓi ƙararrawar ba.",
    )

    fun opening(name: String) = T("J'ouvre $name.", "أفتح $name.", "Ana buɗe $name.")
    fun appMissing(name: String) = T(
        "Je ne trouve pas l'application « $name » sur ce téléphone.",
        "لم أجد تطبيق «$name» على هذا الهاتف.",
        "Ban sami manhajar «$name» a wannan wayar ba.",
    )
    val askAppName = T("Quelle application dois-je ouvrir ?", "أي تطبيق أفتح؟", "Wace manhaja zan buɗe?")
    val cantOpen = T(
        "Android n'a pas permis d'ouvrir cet écran.",
        "لم يسمح أندرويد بفتح هذه الشاشة.",
        "Android bai bari a buɗe wannan shafin ba.",
    )
    val camera = T("J'ouvre la caméra.", "أفتح الكاميرا.", "Ana buɗe kyamara.")
    val settings = T("J'ouvre les paramètres.", "أفتح الإعدادات.", "Ana buɗe saitunan waya.")

    fun dial(num: String?) = if (num == null) {
        T("J'ouvre le clavier du téléphone.", "أفتح لوحة الاتصال.", "Ana buɗe wurin kira.")
    } else {
        T(
            "Numéro $num préparé : appuyez vous-même sur Appeler pour confirmer.",
            "تم تجهيز الرقم $num: اضغط بنفسك على اتصال للتأكيد.",
            "An shirya lamba $num: ka danna Kira da kanka don tabbatarwa.",
        )
    }

    val cleared = T("Historique effacé.", "تم مسح السجل.", "An goge tarihin hira.")
    val nothingToRepeat = T("Je n'ai encore rien dit.", "لم أقل شيئاً بعد.", "Ban faɗi komai ba tukuna.")
    val stopped = T("D'accord, je me tais.", "حسناً، سأتوقف.", "To, na yi shiru.")
    val greeting = T("Bonjour ! Que puis-je faire pour vous ?", "وعليكم السلام! كيف أساعدك؟", "Sannu! Me zan iya yi maka?")
    val thanks = T("Avec plaisir !", "عفواً!", "Babu komai!")

    val help = T(
        "Je comprends : « Ouvre WhatsApp », « Allume / Éteins la lampe », « Augmente / Baisse le volume », « Batterie », « Quelle heure est-il ? », « Quelle est la date ? », « Crée une alarme à six heures », « Ouvre la caméra », « Ouvre les paramètres », « Appelle 98 97 14 36 », « Répète », « Arrête de parler », « Efface la conversation ».",
        "أفهم: «افتح واتساب»، «شغّل / أطفئ المصباح»، «ارفع / اخفض الصوت»، «البطارية»، «كم الساعة؟»، «ما التاريخ؟»، «أنشئ منبهاً الساعة السادسة»، «افتح الكاميرا»، «افتح الإعدادات»، «اتصل بـ 98971436»، «كرر»، «توقف عن الكلام»، «امسح المحادثة».",
        "Ina fahimtar: «Buɗe WhatsApp», «Kunna / Kashe fitila», «Ƙara / Rage sauti», «Batir», «Ƙarfe nawa?», «Yau wace rana?», «Saita ƙararrawa da ƙarfe shida», «Buɗe kyamara», «Buɗe saituna», «Kira 98971436», «Maimaita», «Dakatar da magana», «Share hira».",
    )

    val unknown = T(
        "Je n'ai pas compris cette commande. Dites « aide » pour voir ce que je sais faire. La conversation libre arrivera dans une prochaine version.",
        "لم أفهم هذا الأمر. قل «مساعدة» لمعرفة ما أستطيع فعله. المحادثة الحرة ستأتي في إصدار قادم.",
        "Ban gane wannan umarni ba. Ka ce «taimako» don ganin abin da zan iya yi. Hira ta kyauta za ta zo a sigar gaba.",
    )

    fun recError(code: Int) = when (code) {
        1, 2, 4, 11 -> T(
            "La reconnaissance vocale demande Internet pour cette langue. Écrivez la commande, ou installez la langue hors ligne dans les réglages vocaux de Google.",
            "التعرف على الكلام يحتاج إلى الإنترنت لهذه اللغة. اكتب الأمر، أو ثبّت اللغة دون اتصال من إعدادات Google الصوتية.",
            "Ganewar murya tana buƙatar Intanet don wannan harshe. Ka rubuta umarnin, ko ka saukar da harshen a saitunan murya na Google.",
        )
        6, 7 -> T(
            "Je n'ai rien entendu de clair. Réessayez en parlant près du téléphone.",
            "لم أسمع شيئاً واضحاً. حاول مرة أخرى بالقرب من الهاتف.",
            "Ban ji komai sosai ba. Sake gwadawa kusa da wayar.",
        )
        9 -> Ui.micDenied
        12, 13 -> T(
            "Cette langue n'est pas disponible pour la reconnaissance vocale sur ce téléphone. Écrivez la commande.",
            "هذه اللغة غير متوفرة للتعرف على الكلام في هذا الهاتف. اكتب الأمر.",
            "Wannan harshe ba ya samuwa don ganewar murya a wannan wayar. Ka rubuta umarnin.",
        )
        8 -> T(
            "La reconnaissance vocale est occupée. Réessayez dans un instant.",
            "خدمة التعرف مشغولة. حاول بعد لحظة.",
            "Ganewar murya tana aiki. Sake gwadawa nan da ɗan lokaci.",
        )
        else -> T(
            "Erreur de reconnaissance vocale (code $code). Réessayez ou écrivez la commande.",
            "خطأ في التعرف على الكلام (الرمز $code). حاول مجدداً أو اكتب الأمر.",
            "Kuskure a ganewar murya (lamba $code). Sake gwadawa ko ka rubuta umarnin.",
        )
    }
}
