package com.sahelvoice.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Mode de reconnaissance vocale réellement utilisé. */
enum class RecMode { ON_DEVICE, STANDARD, NONE }

/**
 * Reconnaissance vocale (voix -> texte).
 * Priorité : reconnaissance « sur l'appareil » d'Android (sans Internet, Android 13+),
 * sinon service Android standard en demandant le mode hors ligne.
 */
class VoiceInput(
    private val context: Context,
    private val onListening: (Boolean) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onResult: (String) -> Unit,
    private val onError: (Int) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null

    /** Langues pour lesquelles le mode « sur l'appareil » a échoué. */
    private val onDeviceFailed = mutableSetOf<Lang>()

    fun bestMode(lang: Lang): RecMode {
        if (Build.VERSION.SDK_INT >= 33 &&
            lang !in onDeviceFailed &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) return RecMode.ON_DEVICE
        if (SpeechRecognizer.isRecognitionAvailable(context)) return RecMode.STANDARD
        return RecMode.NONE
    }

    fun start(lang: Lang): RecMode {
        cancel()
        val mode = bestMode(lang)
        val r = when (mode) {
            RecMode.ON_DEVICE -> if (Build.VERSION.SDK_INT >= 33) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                null
            }
            RecMode.STANDARD -> SpeechRecognizer.createSpeechRecognizer(context)
            RecMode.NONE -> null
        } ?: return RecMode.NONE

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onListening(true)
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val txt = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!txt.isNullOrBlank()) onPartial(txt)
            }

            override fun onResults(results: Bundle?) {
                val txt = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                release()
                onListening(false)
                if (txt.isNullOrBlank()) onError(SpeechRecognizer.ERROR_NO_MATCH) else onResult(txt)
            }

            override fun onError(error: Int) {
                release()
                onListening(false)
                // Langue non disponible sur l'appareil : on essaiera le service standard la prochaine fois.
                if (mode == RecMode.ON_DEVICE && (error == 12 || error == 13 || error == 5)) {
                    onDeviceFailed.add(lang)
                }
                onError(error)
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.tag)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        recognizer = r
        onListening(true)
        r.startListening(intent)
        return mode
    }

    fun cancel() {
        val r = recognizer ?: return
        try {
            r.cancel()
        } catch (_: Exception) {
        }
        release()
        onListening(false)
    }

    private fun release() {
        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
    }
}
