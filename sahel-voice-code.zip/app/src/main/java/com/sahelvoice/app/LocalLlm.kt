package com.sahelvoice.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/** Reçoit les morceaux de texte produits par l'IA. Renvoyer false arrête la génération. */
fun interface TokenSink {
    fun onBytes(bytes: ByteArray): Boolean
}

/** Accès direct au moteur llama.cpp compilé dans l'application (bibliothèque libsahelllm.so). */
object LocalLlm {
    val libraryLoaded: Boolean = try {
        System.loadLibrary("sahelllm")
        true
    } catch (e: Throwable) {
        false
    }

    external fun nativeLoad(path: String, threads: Int): Long
    external fun nativeFree(handle: Long)
    external fun nativeGenerate(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        nCtx: Int,
        maxTokens: Int,
        sink: TokenSink,
    ): Int
}

enum class AiState { ABSENT, IMPORTING, LOADING, READY, ERROR }

/**
 * Gère le modèle d'IA : importation du fichier .gguf, chargement, questions/réponses.
 * Tout le calcul se fait sur un fil séparé pour ne jamais bloquer l'écran.
 */
class ChatEngine private constructor(context: Context) {

    /** Appelé (sur le fil principal) quand l'état change. */
    @Volatile var listener: () -> Unit = {}

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs = app.getSharedPreferences("sahel_voice", Context.MODE_PRIVATE)
    private val dir = File(app.filesDir, "models")
    private val modelFile = File(dir, "model.gguf")

    @Volatile var state: AiState = AiState.ABSENT
        private set
    @Volatile var importPercent: Int = 0
        private set
    @Volatile var errorText: String? = null
        private set
    @Volatile var generating: Boolean = false
        private set
    @Volatile private var stopRequested = false
    private var handle = 0L

    /** Mémoire de la discussion avec l'IA (questions et réponses récentes). */
    private val history = ArrayList<Pair<String, String>>()

    val modelName: String get() = prefs.getString("model_name", null) ?: "modèle"
    val modelSizeMb: Long get() = if (modelFile.exists()) modelFile.length() / (1024 * 1024) else 0

    init {
        if (modelFile.exists()) load()
    }

    private fun changed() = main.post { listener() }

    private fun fail(msg: String) {
        errorText = msg
        state = AiState.ERROR
        changed()
    }

    /** Charge le modèle en mémoire (quelques secondes). */
    fun load() {
        state = AiState.LOADING
        errorText = null
        changed()
        worker.execute {
            try {
                if (!LocalLlm.libraryLoaded) return@execute fail("Le moteur d'IA n'a pas pu démarrer sur ce téléphone.")
                if (!modelFile.exists()) {
                    state = AiState.ABSENT
                    changed()
                    return@execute
                }
                if (handle != 0L) {
                    LocalLlm.nativeFree(handle)
                    handle = 0L
                }
                val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
                val h = LocalLlm.nativeLoad(modelFile.absolutePath, threads)
                if (h == 0L) {
                    fail("Ce fichier n'est pas un modèle compatible, ou la mémoire est insuffisante.")
                } else {
                    handle = h
                    state = AiState.READY
                    changed()
                }
            } catch (e: Throwable) {
                fail("Erreur au chargement de l'IA : ${e.message}")
            }
        }
    }

    /** Copie le fichier .gguf choisi par l'utilisateur dans le stockage privé de l'application. */
    fun import(uri: Uri) {
        if (generating) return
        state = AiState.IMPORTING
        importPercent = 0
        errorText = null
        changed()
        worker.execute {
            try {
                val resolver = app.contentResolver
                var name = "modele.gguf"
                var size = -1L
                resolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                dir.mkdirs()
                val free = StatFs(dir.absolutePath).availableBytes
                if (size > 0 && size + 50L * 1024 * 1024 > free) {
                    return@execute fail("Pas assez de place sur le téléphone pour importer ce fichier.")
                }
                val tmp = File(dir, "import.tmp")
                val input = resolver.openInputStream(uri) ?: return@execute fail("Impossible d'ouvrir le fichier choisi.")
                input.use { ins ->
                    tmp.outputStream().use { out ->
                        val head = ByteArray(4)
                        val n = ins.read(head)
                        if (n < 4 || String(head, Charsets.US_ASCII) != "GGUF") {
                            tmp.delete()
                            return@execute fail("Ce fichier n'est pas un modèle .gguf. Choisissez le fichier téléchargé qui se termine par « .gguf ».")
                        }
                        out.write(head)
                        val buf = ByteArray(1024 * 1024)
                        var copied = 4L
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                            copied += r
                            if (size > 0) {
                                val p = (copied * 100 / size).toInt()
                                if (p != importPercent) {
                                    importPercent = p
                                    changed()
                                }
                            }
                        }
                        if (size > 0 && copied != size) {
                            tmp.delete()
                            return@execute fail("Le fichier semble incomplet (téléchargement interrompu ?). Téléchargez-le à nouveau.")
                        }
                    }
                }
                if (handle != 0L) {
                    LocalLlm.nativeFree(handle)
                    handle = 0L
                }
                modelFile.delete()
                if (!tmp.renameTo(modelFile)) return@execute fail("Impossible d'enregistrer le modèle.")
                prefs.edit().putString("model_name", name).apply()
                main.post { load() }
            } catch (e: Throwable) {
                fail("Erreur pendant l'importation : ${e.message}")
            }
        }
    }

    /** Supprime le modèle du téléphone pour libérer de la place. */
    fun delete() {
        if (generating) return
        worker.execute {
            if (handle != 0L) {
                LocalLlm.nativeFree(handle)
                handle = 0L
            }
            modelFile.delete()
            File(dir, "import.tmp").delete()
            state = AiState.ABSENT
            changed()
        }
    }

    /** true si la mémoire libre semble trop faible pour ce modèle. */
    fun memoryLooksLow(): Boolean = try {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        mi.availMem < modelFile.length() / 2 + 200L * 1024 * 1024
    } catch (e: Throwable) {
        false
    }

    fun stop() {
        stopRequested = true
    }

    fun clearHistory() {
        synchronized(history) { history.clear() }
    }

    /**
     * Pose une question à l'IA.
     * onPartial reçoit le texte au fur et à mesure ; onDone reçoit le texte final (ou une erreur).
     */
    fun ask(question: String, onPartial: (String) -> Unit, onDone: (String?, String?) -> Unit) {
        if (state != AiState.READY || generating) {
            onDone(null, "L'IA n'est pas prête.")
            return
        }
        generating = true
        stopRequested = false
        changed()
        worker.execute {
            var answer: String? = null
            var err: String? = null
            try {
                val past = synchronized(history) { ArrayList(history) }
                var keep = past.size
                var code = 0
                val bytes = ByteArrayOutputStream()
                var lastPost = 0L
                while (true) {
                    bytes.reset()
                    val roles = ArrayList<String>()
                    val contents = ArrayList<String>()
                    roles.add("system"); contents.add(SYSTEM_PROMPT)
                    for ((q, a) in past.takeLast(keep)) {
                        roles.add("user"); contents.add(q)
                        roles.add("assistant"); contents.add(a)
                    }
                    roles.add("user"); contents.add(question)
                    code = LocalLlm.nativeGenerate(
                        handle, roles.toTypedArray(), contents.toTypedArray(), N_CTX, MAX_TOKENS,
                    ) { b ->
                        bytes.write(b)
                        val now = System.currentTimeMillis()
                        if (now - lastPost > 120) {
                            lastPost = now
                            val txt = clean(String(bytes.toByteArray(), Charsets.UTF_8))
                            main.post { onPartial(txt) }
                        }
                        !stopRequested
                    }
                    // Conversation trop longue : on oublie les plus anciens échanges et on recommence.
                    if (code == ERR_TOO_LONG && keep > 0) {
                        keep = (keep / 2).coerceAtMost(keep - 1)
                        continue
                    }
                    break
                }
                if (code >= 0) {
                    answer = clean(String(bytes.toByteArray(), Charsets.UTF_8)).ifBlank { "(pas de réponse)" }
                    if (!stopRequested) {
                        synchronized(history) {
                            history.add(question to answer!!)
                            while (history.size > MAX_EXCHANGES) history.removeAt(0)
                        }
                    }
                } else {
                    err = when (code) {
                        ERR_TOO_LONG -> "Votre message est trop long pour l'IA. Raccourcissez-le."
                        ERR_CONTEXT -> "Mémoire insuffisante pour répondre. Fermez d'autres applications et réessayez."
                        else -> "L'IA a rencontré une erreur (code $code)."
                    }
                }
            } catch (e: Throwable) {
                err = "Erreur de l'IA : ${e.message}"
            }
            generating = false
            val a = answer
            val e = err
            main.post {
                onDone(a, e)
                listener()
            }
        }
    }

    companion object {
        @Volatile private var instance: ChatEngine? = null

        /**
         * Un seul moteur pour toute l'application : le modèle (jusqu'à 1 Go) ne doit jamais
         * être chargé deux fois en mémoire, même si l'écran est recréé.
         */
        fun get(context: Context, onChange: () -> Unit): ChatEngine = synchronized(this) {
            val e = instance ?: ChatEngine(context).also { instance = it }
            e.listener = onChange
            e
        }

        private const val N_CTX = 2048
        private const val MAX_TOKENS = 220
        private const val MAX_EXCHANGES = 6
        private const val ERR_TOO_LONG = -3
        private const val ERR_CONTEXT = -2

        const val SYSTEM_PROMPT =
            "Tu es Sahel Voice, un assistant personnel qui parle français. " +
                "Règles : réponds uniquement à la question posée ; " +
                "écris en français correct et simple ; " +
                "fais une réponse courte de 2 à 4 phrases, sauf si l'utilisateur demande plus de détails ; " +
                "n'invente rien : si tu ne sais pas, dis « Je ne suis pas sûr » ; " +
                "tu ne connais pas l'actualité récente."

        /** Retire la mise en forme (gras, titres) que la voix lirait mal. */
        fun clean(s: String): String = s
            .replace("**", "")
            .replace("__", "")
            .replace(Regex("(?m)^#+\\s*"), "")
            .replace(Regex("(?m)^\\s*[*-]\\s+"), "• ")
            .replace("�", "")
            .trim()

        /** Modèles proposés (vérifiés sur Hugging Face, licence Apache 2.0). */
        const val URL_RECOMMENDED =
            "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"
        const val URL_LIGHT =
            "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_0.gguf?download=true"
    }
}
