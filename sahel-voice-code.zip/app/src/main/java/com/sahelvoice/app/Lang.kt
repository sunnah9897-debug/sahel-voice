package com.sahelvoice.app

import java.util.Locale

/** Les trois langues de l'application. */
enum class Lang(
    val code: String,
    /** Étiquette BCP-47 envoyée à la reconnaissance vocale. */
    val tag: String,
    /** Texte court du bouton de langue. */
    val short: String,
    val rtl: Boolean,
) {
    FR("fr", "fr-FR", "Français", false),
    AR("ar", "ar-SA", "العربية", true),
    HA("ha", "ha-NG", "Hausa", false);

    val locale: Locale get() = Locale.forLanguageTag(tag)

    companion object {
        fun fromCode(c: String?): Lang = entries.firstOrNull { it.code == c } ?: FR
    }
}

/** Un texte disponible dans les trois langues. */
class T(val fr: String, val ar: String, val ha: String) {
    operator fun get(l: Lang): String = when (l) {
        Lang.FR -> fr
        Lang.AR -> ar
        Lang.HA -> ha
    }
}

/** Textes de l'interface. Les phrases haoussa sont à faire relire par des locuteurs natifs. */
object Ui {
    val appName = T("Sahel Voice", "ساحل فويس", "Sahel Voice")
    val local = T(
        "🔒 Mode local · aucune connexion Internet",
        "🔒 وضع محلي · بدون اتصال بالإنترنت",
        "🔒 Cikin waya kawai · ba Intanet",
    )
    val emptyHint = T(
        "Touchez le micro et parlez, ou écrivez une commande.\n\nEssayez : « Allume la lampe », « Quelle heure est-il ? », « Ouvre WhatsApp ».\n\nPour discuter librement, installez l'IA avec 🧠, puis demandez par exemple : « Explique-moi la photosynthèse ».",
        "اضغط على الميكروفون وتكلم، أو اكتب أمراً.\n\nجرّب: «شغّل المصباح»، «كم الساعة؟»، «افتح واتساب»، «مساعدة».",
        "Taɓa makirufo ka yi magana, ko ka rubuta umarni.\n\nGwada: «Kunna fitila», «Ƙarfe nawa?», «Buɗe WhatsApp», «Taimako».",
    )
    val listening = T("J'écoute… touchez 🎤 pour arrêter", "أستمع… اضغط 🎤 للإيقاف", "Ina sauraro… taɓa 🎤 don tsayawa")
    val typeHere = T("Écrire une commande…", "اكتب أمراً…", "Rubuta umarni…")
    val badgeAction = T("✔ Action exécutée", "✔ تم التنفيذ", "✔ An aiwatar")
    val badgeInfo = T("ℹ Réponse", "ℹ إجابة", "ℹ Amsa")
    val badgeError = T("⚠ Problème", "⚠ مشكلة", "⚠ Matsala")
    val clearTitle = T("Effacer l'historique ?", "مسح السجل؟", "A goge tarihin hira?")
    val clearText = T(
        "Toute la conversation enregistrée sur ce téléphone sera supprimée.",
        "سيتم حذف كل المحادثة المحفوظة على هذا الهاتف.",
        "Za a goge duk hirar da aka ajiye a wannan wayar.",
    )
    val clearYes = T("Effacer", "مسح", "Goge")
    val cancel = T("Annuler", "إلغاء", "Soke")

    val voiceOff = T("🔇 Voix désactivée (réponses écrites)", "🔇 الصوت متوقف (ردود مكتوبة)", "🔇 An kashe murya (amsa a rubuce)")
    val voiceLoading = T("🔊 Préparation de la voix…", "🔊 جارٍ تجهيز الصوت…", "🔊 Ana shirya murya…")
    val voiceOffline = T("🔊 Voix hors ligne disponible", "🔊 صوت يعمل دون إنترنت متوفر", "🔊 Akwai murya ba tare da Intanet ba")
    val voiceOnline = T(
        "🔊 Voix disponible, mais elle peut demander Internet",
        "🔊 الصوت متوفر لكنه قد يحتاج إلى الإنترنت",
        "🔊 Akwai murya, amma tana iya buƙatar Intanet",
    )
    val voiceNone = T(
        "🔈 Pas de voix pour cette langue : réponses écrites",
        "🔈 لا يوجد صوت لهذه اللغة: الردود مكتوبة",
        "🔈 Babu murya don wannan harshe: amsa a rubuce",
    )
    val voiceMissing = T(
        "🔈 La voix de cette langue n'est pas encore téléchargée",
        "🔈 صوت هذه اللغة غير محمّل بعد",
        "🔈 Ba a saukar da muryar wannan harshe ba tukuna",
    )
    val installVoice = T(
        "➕ Installer / vérifier la voix (touchez ici)",
        "➕ تثبيت / فحص الصوت (اضغط هنا)",
        "➕ Saukar / duba murya (taɓa nan)",
    )
    val recOnDevice = T("🎤 Reconnaissance sur le téléphone", "🎤 التعرف على الكلام داخل الهاتف", "🎤 Ganewar murya a cikin waya")
    val recStandard = T(
        "🎤 Reconnaissance par le service Android (peut utiliser Internet)",
        "🎤 التعرف عبر خدمة أندرويد (قد تستخدم الإنترنت)",
        "🎤 Ganewa ta hanyar Android (tana iya amfani da Intanet)",
    )
    val recNone = T(
        "🎤 Aucune reconnaissance vocale sur ce téléphone : écrivez vos commandes",
        "🎤 لا يوجد تعرف على الكلام في هذا الهاتف: اكتب أوامرك",
        "🎤 Babu ganewar murya a wannan wayar: ka rubuta umarni",
    )
    val micDenied = T(
        "Le micro est refusé. Autorisez-le : Paramètres > Applications > Sahel Voice > Autorisations > Micro.",
        "تم رفض الميكروفون. اسمح به من: الإعدادات > التطبيقات > Sahel Voice > الأذونات > الميكروفون.",
        "An ƙi makirufo. Ka ba da izini: Saituna > Manhajoji > Sahel Voice > Izini > Makirufo.",
    )
}
