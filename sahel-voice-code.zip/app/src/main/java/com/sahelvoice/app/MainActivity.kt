package com.sahelvoice.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

private var crashRecorderInstalled = false

class MainActivity : ComponentActivity() {

    private lateinit var assistant: Assistant

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) assistant.importModel(uri)
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) assistant.startListening() else assistant.micDenied()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashRecorder()
        super.onCreate(savedInstanceState)
        // L'en-tête est toujours vert foncé : icônes de la barre d'état en clair.
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT))
        assistant = Assistant(this)
        setContent {
            SahelTheme {
                MainScreen(
                    assistant,
                    onMic = ::onMicPressed,
                    onPickModel = { pickModel.launch(arrayOf("*/*")) },
                )
            }
        }
    }

    /** En cas de plantage, garde la cause pour l'afficher au prochain démarrage. */
    private fun installCrashRecorder() {
        if (crashRecorderInstalled) return
        crashRecorderInstalled = true
        val prefs = applicationContext.getSharedPreferences("sahel_voice", MODE_PRIVATE)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                prefs.edit()
                    .putString(HistoryStore.KEY_CRASH, android.util.Log.getStackTraceString(error).take(4000))
                    .commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    private fun onMicPressed() {
        if (assistant.listening) {
            assistant.stopListening()
            return
        }
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) assistant.startListening() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onPause() {
        super.onPause()
        // Jamais d'écoute en arrière-plan.
        if (assistant.listening) assistant.stopListening()
    }

    override fun onDestroy() {
        assistant.shutdown()
        super.onDestroy()
    }
}
