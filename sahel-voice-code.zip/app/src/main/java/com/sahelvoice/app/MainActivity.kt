package com.sahelvoice.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

private var crashRecorderInstalled = false
private const val ACTION_LISTEN = "com.sahelvoice.app.LISTEN"

class MainActivity : ComponentActivity() {

    private lateinit var assistant: Assistant

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) assistant.importModel(uri)
    }

    private val pickWake = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) WakeModel.import(this, uri)
    }

    private val askMicForBackground = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            toggleBackground(true)
        } else {
            WakeStatus.line = "⚠ Sans le micro, l'écoute en arrière-plan est impossible."
        }
    }

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        // Même si les notifications sont refusées, Android autorise l'écoute (la notification sera juste masquée).
        ListenService.start(this)
    }

    /** Active ou arrête l'écoute en arrière-plan. */
    private fun toggleBackground(on: Boolean) {
        if (!on) {
            ListenService.stop(this)
            return
        }
        if (!WakeModel.installed(this)) {
            WakeStatus.line = "Installez d'abord le modèle de mot d'activation (étapes 1 et 2)."
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askMicForBackground.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        try {
            ListenService.start(this)
        } catch (e: Throwable) {
            WakeStatus.line = "⚠ Android a refusé de démarrer l'écoute : ${e.message}"
        }
    }

    override fun onResume() {
        super.onResume()
        ListenService.appInForeground = true
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) assistant.startListening() else assistant.micDenied()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashRecorder()
        super.onCreate(savedInstanceState)
        // L'en-tête est toujours vert foncé : icônes de la barre d'état en clair.
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT))
        assistant = Assistant(this)
        setContent {
            SahelTheme {
                MainScreen(
                    assistant,
                    onMic = ::onMicPressed,
                    onPickModel = { pickModel.launch(arrayOf("*/*")) },
                    onPickWake = { pickWake.launch(arrayOf("*/*")) },
                    onToggleBackground = ::toggleBackground,
                )
            }
        }
        if (savedInstanceState == null) handleLaunch(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunch(intent)
    }

    /** Ouverture par appui long (assistant) ou par le raccourci « Écouter » : on écoute tout de suite. */
    private fun handleLaunch(intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_ASSIST || action == Intent.ACTION_VOICE_COMMAND || action == ACTION_LISTEN) {
            window.decorView.postDelayed({
                if (!assistant.listening) onMicPressed()
            }, 400)
        }
    }

    /** En cas de plantage, garde la cause pour l'afficher au prochain démarrage. */
    private fun installCrashRecorder() {
        if (crashRecorderInstalled) return
        crashRecorderInstalled = true
        val prefs = applicationContext.getSharedPreferences("sahel_voice", MODE_PRIVATE)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                prefs.edit()
                    .putString(HistoryStore.KEY_CRASH, android.util.Log.getStackTraceString(error).take(4000))
                    .commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    private fun onMicPressed() {
        if (assistant.listening) {
            assistant.stopListening()
            return
        }
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) assistant.startListening() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onPause() {
        super.onPause()
        ListenService.appInForeground = false
        // Jamais d'écoute en arrière-plan.
        if (assistant.listening) assistant.stopListening()
    }

    override fun onDestroy() {
        assistant.shutdown()
        super.onDestroy()
    }
}
